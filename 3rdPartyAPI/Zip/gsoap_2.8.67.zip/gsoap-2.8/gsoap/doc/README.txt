
To browse the documentation, open the index.html file in a browser.

Or you can navigate to https://www.genivia.com/docs.html for the latest
documentation and software updates.

