#include <curses.h>
#include <panel.h>

int main(int argc, char** argv)
{
    WINDOW w;
    PANEL p;
    (void)(w);
    (void)(p);
    (void)(argc);
    (void)(argv);
    return 0;
}

