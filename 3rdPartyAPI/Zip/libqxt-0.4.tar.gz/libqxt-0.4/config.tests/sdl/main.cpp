#include <SDL/SDL.h>


int main (int,char**)
	{
        SDL_Quit();
	return 0;
	}


