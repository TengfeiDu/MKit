/****************************************************************************
**
** Copyright (C) Qxt Foundation. Some rights reserved.
**
** This file is part of the QxtCore module of the Qxt library.
**
** This library is free software; you can redistribute it and/or modify it
** under the terms of the Common Public License, version 1.0, as published by
** IBM.
**
** This file is provided "AS IS", without WARRANTIES OR CONDITIONS OF ANY
** KIND, EITHER EXPRESS OR IMPLIED INCLUDING, WITHOUT LIMITATION, ANY
** WARRANTIES OR CONDITIONS OF TITLE, NON-INFRINGEMENT, MERCHANTABILITY OR
** FITNESS FOR A PARTICULAR PURPOSE.
**
** You should have received a copy of the CPL along with this file.
** See the LICENSE file and the cpl1.0.txt file included with the source
** distribution for more information. If you did not receive a copy of the
** license, contact the Qxt Foundation.
**
** <http://libqxt.org>  <foundation@libqxt.org>
**
****************************************************************************/

/**
\class QxtMultiSignalWaiter QxtMultiSignalWaiter

\ingroup QxtCore

\brief Block and process events until a group of signals is emitted

Code written in a synchronous style will sometimes need to block until any of several conditions are met,
or until all of a set of conditions are met. This class allows a group of signals to be defined and waited
upon in a simple AND or OR fashion. More complex Boolean relationships can be written by connecting
together multiple QxtSignalGroup objects and waiting for all or any of these groups to emit one of
their signals.

\bug
QxtMultiSignalWaiter is subject to the same reentrancy problems as QxtSignalWaiter.

\sa QxtSignalWaiter
*/

#include "qxtsignalwaiter.h"
#include "qxtmultisignalwaiter.h"

/**
 * Constructs a QxtMultiSignalWaiter with the specified parent.
 */
QxtMultiSignalWaiter::QxtMultiSignalWaiter(QObject* parent) : QxtSignalGroup(parent) {
    /* initializers only */
}

/**
 * \reimp
 */
QxtMultiSignalWaiter::~QxtMultiSignalWaiter() {
    /* no-op */
}

/**
 * Blocks the current function until any of the signals in the group are emitted.
 * If msec is not -1, waitForAny() will return before a signal is emitted if the
 * specified  number of milliseconds have elapsed. Returns true if a signal was
 * caught, or false if the timeout elapsed.
 * Note that waitForAny() may continue to block after a signal is emitted or the
 * timeout elapses; the function only guarantees that it will not return BEFORE
 * one of these conditions has occurred. This function is not reentrant.
 *
 * \sa QxtSignalGroup::addSignal
 * \sa QxtSignalGroup::firstSignalEmitted
 */
bool QxtMultiSignalWaiter::waitForAny(int msec, QEventLoop::ProcessEventsFlags flags) {
    if(hasReceivedFirstSignal()) return true;
    return QxtSignalWaiter::wait(this, SIGNAL(firstSignalReceived()), msec, flags);
}

/**
 * Blocks the current function until all of the signals in the group have been
 * emitted. If msec is not -1, waitForAll() will return before all of the signals
 * are emitted if the specified  number of milliseconds have elapsed. Returns
 * true if each signal was caught at least once, or false if the timeout elapsed.
 * Note that waitForAll() may continue to block after the last signal is emitted
 * or the timeout elapses; the function only guarantees that it will not return
 * BEFORE one of these conditions has occurred. This function is not reentrant.
 *
 * \sa QxtSignalGroup::addSignal
 * \sa QxtSignalGroup::allSignalsEmitted
 */
bool QxtMultiSignalWaiter::waitForAll(int msec, QEventLoop::ProcessEventsFlags flags) {
    if(hasReceivedAllSignals()) return true;
    return QxtSignalWaiter::wait(this, SIGNAL(allSignalsReceived()), msec, flags);
}

