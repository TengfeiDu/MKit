#include "qxtscheduleviewtest.h"

QxtScheduleViewTest::QxtScheduleViewTest(QWidget *parent)
    : QMainWindow(parent)
{
	ui.setupUi(this);
}

QxtScheduleViewTest::~QxtScheduleViewTest()
{

}
