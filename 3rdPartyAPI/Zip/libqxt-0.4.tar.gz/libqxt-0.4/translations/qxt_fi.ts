<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fi">
<defaultcodec></defaultcodec>
<context>
    <name>QLocale</name>
    <message>
        <location filename="gen_qlocale.cpp" line="49"/>
        <source>German</source>
        <translation>Saksa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="8"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="9"/>
        <source>Abkhazian</source>
        <translation>Abhaasi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="10"/>
        <source>Afan</source>
        <translation>Afan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="11"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="12"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="13"/>
        <source>Albanian</source>
        <translation>Albania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="14"/>
        <source>Amharic</source>
        <translation>Amhara</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="15"/>
        <source>Arabic</source>
        <translation>Arabia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="16"/>
        <source>Armenian</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="17"/>
        <source>Assamese</source>
        <translation>Assami</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="18"/>
        <source>Aymara</source>
        <translation>Aimara</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="19"/>
        <source>Azerbaijani</source>
        <translation>Azeri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="20"/>
        <source>Bashkir</source>
        <translation>Baškiiri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="21"/>
        <source>Basque</source>
        <translation>Baski</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="22"/>
        <source>Bengali</source>
        <translation>Bengali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="23"/>
        <source>Bhutani</source>
        <translation>Bhutani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="24"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="25"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="26"/>
        <source>Breton</source>
        <translation>Bretoni</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="27"/>
        <source>Bulgarian</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="28"/>
        <source>Burmese</source>
        <translation>Burma</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="29"/>
        <source>Byelorussian</source>
        <translation>Valkovenäjä</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="30"/>
        <source>Cambodian</source>
        <translation>Kambodža</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="31"/>
        <source>Catalan</source>
        <translation>Katalaani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="32"/>
        <source>Chinese</source>
        <translation>Kiina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="33"/>
        <source>Corsican</source>
        <translation>Korsika</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="34"/>
        <source>Croatian</source>
        <translation>Kroatia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="35"/>
        <source>Czech</source>
        <translation>Tšekki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="36"/>
        <source>Danish</source>
        <translation>Tanska</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="37"/>
        <source>Dutch</source>
        <translation>Hollanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="38"/>
        <source>English</source>
        <translation>Englanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="39"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="40"/>
        <source>Estonian</source>
        <translation>Eesti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="41"/>
        <source>Faroese</source>
        <translation>Fääri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="42"/>
        <source>FijiLanguage</source>
        <translation>Fidži</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="43"/>
        <source>Finnish</source>
        <translation>Suomi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="44"/>
        <source>French</source>
        <translation>Ranska</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="45"/>
        <source>Frisian</source>
        <translation>Friisi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="46"/>
        <source>Gaelic</source>
        <translation>Gaeli</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="47"/>
        <source>Galician</source>
        <translation>Galego</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="48"/>
        <source>Georgian</source>
        <translation>Georgia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="50"/>
        <source>Greek</source>
        <translation>Kreikka</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="51"/>
        <source>Greenlandic</source>
        <translation>Grönlanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="52"/>
        <source>Guarani</source>
        <translation>Guarani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="53"/>
        <source>Gujarati</source>
        <translation>Gudžarati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="54"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="55"/>
        <source>Hebrew</source>
        <translation>Heprea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="56"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="57"/>
        <source>Hungarian</source>
        <translation>Unkari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="58"/>
        <source>Icelandic</source>
        <translation>Islanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="59"/>
        <source>Indonesian</source>
        <translation>Indonesia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="60"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="61"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="62"/>
        <source>Inuktitut</source>
        <translation>Eskimo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="63"/>
        <source>Inupiak</source>
        <translation>Inupiak</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="64"/>
        <source>Irish</source>
        <translation>Iiri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="65"/>
        <source>Italian</source>
        <translation>Italia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="66"/>
        <source>Japanese</source>
        <translation>Japani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="67"/>
        <source>Javanese</source>
        <translation>Jaava</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="68"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="69"/>
        <source>Kashmiri</source>
        <translation>Kašmiri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="70"/>
        <source>Kazakh</source>
        <translation>Kazak</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="71"/>
        <source>Kinyarwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="72"/>
        <source>Kirghiz</source>
        <translation>Kirgiisi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="73"/>
        <source>Korean</source>
        <translation>Korea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="74"/>
        <source>Kurdish</source>
        <translation>Kurdi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="75"/>
        <source>Kurundi</source>
        <translation>Kurundi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="76"/>
        <source>Laothian</source>
        <translation>Lao</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="77"/>
        <source>Latin</source>
        <translation>Latina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="78"/>
        <source>Latvian</source>
        <translation>Latvia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="79"/>
        <source>Lingala</source>
        <translation>Lingala</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="80"/>
        <source>Lithuanian</source>
        <translation>Liettua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="81"/>
        <source>Macedonian</source>
        <translation>Makedonia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="82"/>
        <source>Malagasy</source>
        <translation>Malagassi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="83"/>
        <source>Malay</source>
        <translation>Malaiji</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="84"/>
        <source>Malayalam</source>
        <translation>Malajalam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="85"/>
        <source>Maltese</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="86"/>
        <source>Maori</source>
        <translation>Maori</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="87"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="88"/>
        <source>Moldavian</source>
        <translation>Moldavia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="89"/>
        <source>Mongolian</source>
        <translation>Mongoli</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="90"/>
        <source>NauruLanguage</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="91"/>
        <source>Nepali</source>
        <translation>Nepali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="92"/>
        <source>Norwegian</source>
        <translation>Norja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="93"/>
        <source>NorwegianBokmal</source>
        <translation>Kirjanorja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="94"/>
        <source>Occitan</source>
        <translation>Oksitaani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="95"/>
        <source>Oriya</source>
        <translation>Orija</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="96"/>
        <source>Pashto</source>
        <translation>Paštu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="97"/>
        <source>Persian</source>
        <translation>Persia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="98"/>
        <source>Polish</source>
        <translation>Puola</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="99"/>
        <source>Portuguese</source>
        <translation>Portugali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="100"/>
        <source>Punjabi</source>
        <translation>Pandžabi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="101"/>
        <source>Quechua</source>
        <translation>Ketšua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="102"/>
        <source>RhaetoRomance</source>
        <translation>Retoromaani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="103"/>
        <source>Romanian</source>
        <translation>Romania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="104"/>
        <source>Russian</source>
        <translation>Venäjä</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="105"/>
        <source>Samoan</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="106"/>
        <source>Sangho</source>
        <translation>Sangho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="107"/>
        <source>Sanskrit</source>
        <translation>Sanskriitti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="108"/>
        <source>Serbian</source>
        <translation>Serbia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="109"/>
        <source>SerboCroatian</source>
        <translation>Serbian Kroatia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="110"/>
        <source>Sesotho</source>
        <translation>Sesotho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="111"/>
        <source>Setswana</source>
        <translation>Setšwana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="112"/>
        <source>Shona</source>
        <translation>Shona</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="113"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="114"/>
        <source>Singhalese</source>
        <translation>Singhali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="115"/>
        <source>Siswati</source>
        <translation>Siswati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="116"/>
        <source>Slovak</source>
        <translation>Slovakki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="117"/>
        <source>Slovenian</source>
        <translation>Sloveeni</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="118"/>
        <source>Somali</source>
        <translation>Somali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="119"/>
        <source>Spanish</source>
        <translation>Espanja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="120"/>
        <source>Sundanese</source>
        <translation>Sundaneesi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="121"/>
        <source>Swahili</source>
        <translation>Swahili</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="122"/>
        <source>Swedish</source>
        <translation>Ruotsi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="123"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="124"/>
        <source>Tajik</source>
        <translation>Tadžikki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="125"/>
        <source>Tamil</source>
        <translation>Tamili</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="126"/>
        <source>Tatar</source>
        <translation>Tataari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="127"/>
        <source>Telugu</source>
        <translation>Telugu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="128"/>
        <source>Thai</source>
        <translation>Thai</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="129"/>
        <source>Tibetan</source>
        <translation>Tiibetti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="130"/>
        <source>Tigrinya</source>
        <translation>Tigrinja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="131"/>
        <source>TongaLanguage</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="132"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="133"/>
        <source>Turkish</source>
        <translation>Turkki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="134"/>
        <source>Turkmen</source>
        <translation>Turkmeeni</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="135"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="136"/>
        <source>Uigur</source>
        <translation>Uiguuri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="137"/>
        <source>Ukrainian</source>
        <translation>Ukraina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="138"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="139"/>
        <source>Uzbek</source>
        <translation>Uzbekki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="140"/>
        <source>Vietnamese</source>
        <translation>Vietnami</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="141"/>
        <source>Volapuk</source>
        <translation>Volapük</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="142"/>
        <source>Welsh</source>
        <translation>Kymri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="143"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="144"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="145"/>
        <source>Yiddish</source>
        <translation>Jiddiš</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="146"/>
        <source>Yoruba</source>
        <translation>Joruba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="147"/>
        <source>Zhuang</source>
        <translation>Tšuang</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="148"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="149"/>
        <source>NorwegianNynorsk</source>
        <translation>Uusnorja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="150"/>
        <source>Nynorsk</source>
        <translation>Uusnorja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="151"/>
        <source>Bosnian</source>
        <translation>Bosnia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="152"/>
        <source>Divehi</source>
        <translation>Divehi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="153"/>
        <source>Manx</source>
        <translation>Manksi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="154"/>
        <source>Cornish</source>
        <translation>Korni</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="155"/>
        <source>Akan</source>
        <translation>Akan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="156"/>
        <source>Konkani</source>
        <translation>Konkani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="157"/>
        <source>Ga</source>
        <translation>Ga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="158"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="159"/>
        <source>Kamba</source>
        <translation>Kamba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="160"/>
        <source>Syriac</source>
        <translation>Syyria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="161"/>
        <source>Blin</source>
        <translation>Blin</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="162"/>
        <source>Geez</source>
        <translation>Etiopia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="163"/>
        <source>Koro</source>
        <translation>Koro</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="164"/>
        <source>Sidamo</source>
        <translation>Sidamo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="165"/>
        <source>Atsam</source>
        <translation>Atsam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="166"/>
        <source>Tigre</source>
        <translation>Tigre</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="167"/>
        <source>Jju</source>
        <translation>Jju</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="168"/>
        <source>Friulian</source>
        <translation>Friuliaani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="169"/>
        <source>Venda</source>
        <translation>Venda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="170"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="171"/>
        <source>Walamo</source>
        <translation>Walamo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="172"/>
        <source>Hawaiian</source>
        <translation>Havaiji</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="173"/>
        <source>Tyap</source>
        <translation>Tyap</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="176"/>
        <source>AnyCountry</source>
        <translation>Tuntematon Valtio</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="177"/>
        <source>Afghanistan</source>
        <translation>Afganistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="178"/>
        <source>Albania</source>
        <translation>Albania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="179"/>
        <source>Algeria</source>
        <translation>Algeria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="180"/>
        <source>AmericanSamoa</source>
        <translation>Amerikan Samoa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="181"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="182"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="183"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="184"/>
        <source>Antarctica</source>
        <translation>Antarktis</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="185"/>
        <source>AntiguaAndBarbuda</source>
        <translation>Antigua ja Barbuda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="186"/>
        <source>Argentina</source>
        <translation>Argentiina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="187"/>
        <source>Armenia</source>
        <translation>Armenia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="188"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="189"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="190"/>
        <source>Austria</source>
        <translation>Itävalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="191"/>
        <source>Azerbaijan</source>
        <translation>Azerbaidžan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="192"/>
        <source>Bahamas</source>
        <translation>Bahama</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="193"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="194"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="195"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="196"/>
        <source>Belarus</source>
        <translation>Valko-Venäjä</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="197"/>
        <source>Belgium</source>
        <translation>Belgia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="198"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="199"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="200"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="201"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="202"/>
        <source>Bolivia</source>
        <translation>Bolivia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="203"/>
        <source>BosniaAndHerzegowina</source>
        <translation>Bosnia ja Hertsegovina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="204"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="205"/>
        <source>BouvetIsland</source>
        <translation>Bouvet&apos;nsaari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="206"/>
        <source>Brazil</source>
        <translation>Brasilia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="207"/>
        <source>BritishIndianOceanTerritory</source>
        <translation>Brittiläinen Intian Valtameren Alue</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="208"/>
        <source>BruneiDarussalam</source>
        <translation>Brunei</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="209"/>
        <source>Bulgaria</source>
        <translation>Bulgaria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="210"/>
        <source>BurkinaFaso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="211"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="212"/>
        <source>Cambodia</source>
        <translation>Kambodža</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="213"/>
        <source>Cameroon</source>
        <translation>Kamerun</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="214"/>
        <source>Canada</source>
        <translation>Kanada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="215"/>
        <source>CapeVerde</source>
        <translation>Kap Verde</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="216"/>
        <source>CaymanIslands</source>
        <translation>Caymansaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="217"/>
        <source>CentralAfricanRepublic</source>
        <translation>Keski-Afrikan Tasavalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="218"/>
        <source>Chad</source>
        <translation>Tšad</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="219"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="220"/>
        <source>China</source>
        <translation>Kiina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="221"/>
        <source>ChristmasIsland</source>
        <translation>Joulusaari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="222"/>
        <source>CocosIslands</source>
        <translation>Kookossaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="223"/>
        <source>Colombia</source>
        <translation>Kolumbia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="224"/>
        <source>Comoros</source>
        <translation>Komorit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="225"/>
        <source>DemocraticRepublicOfCongo</source>
        <translation>Kongon Demokraattinen Tasavalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="226"/>
        <source>PeoplesRepublicOfCongo</source>
        <translation>Kongon Tasavalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="227"/>
        <source>CookIslands</source>
        <translation>Cookinsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="228"/>
        <source>CostaRica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="229"/>
        <source>IvoryCoast</source>
        <translation>Norsunluurannikko</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="230"/>
        <source>Croatia</source>
        <translation>Kroatia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="231"/>
        <source>Cuba</source>
        <translation>Kuuba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="232"/>
        <source>Cyprus</source>
        <translation>Kypros</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="233"/>
        <source>CzechRepublic</source>
        <translation>Tšekki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="234"/>
        <source>Denmark</source>
        <translation>Tanska</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="235"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="236"/>
        <source>Dominica</source>
        <translation>Dominica</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="237"/>
        <source>DominicanRepublic</source>
        <translation>Dominikaaninen Tasavalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="238"/>
        <source>EastTimor</source>
        <translation>Itä-Timor</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="239"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="240"/>
        <source>Egypt</source>
        <translation>Egypti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="241"/>
        <source>ElSalvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="242"/>
        <source>EquatorialGuinea</source>
        <translation>Päiväntasaajan Guinea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="243"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="244"/>
        <source>Estonia</source>
        <translation>Eesti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="245"/>
        <source>Ethiopia</source>
        <translation>Etiopia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="246"/>
        <source>FalklandIslands</source>
        <translation>Falklandinsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="247"/>
        <source>FaroeIslands</source>
        <translation>Färsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="248"/>
        <source>FijiCountry</source>
        <translation>Fidži</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="249"/>
        <source>Finland</source>
        <translation>Suomi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="250"/>
        <source>France</source>
        <translation>Ranska</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="251"/>
        <source>MetropolitanFrance</source>
        <translation>Ranska (Eurooppaan kuuluvat osat)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="252"/>
        <source>FrenchGuiana</source>
        <translation>Ranskan Guayana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="253"/>
        <source>FrenchPolynesia</source>
        <translation>Ranskan Polynesia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="254"/>
        <source>FrenchSouthernTerritories</source>
        <translation>Ranskan Eteläiset Alueet</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="255"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="256"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="257"/>
        <source>Georgia</source>
        <translation>Georgia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="258"/>
        <source>Germany</source>
        <translation>Saksa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="259"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="260"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="261"/>
        <source>Greece</source>
        <translation>Kreikka</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="262"/>
        <source>Greenland</source>
        <translation>Gröönlanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="263"/>
        <source>Grenada</source>
        <translation>Grenada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="264"/>
        <source>Guadeloupe</source>
        <translation>Guadeloupe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="265"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="266"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="267"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="268"/>
        <source>GuineaBissau</source>
        <translation>Guinea-Bissau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="269"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="270"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="271"/>
        <source>HeardAndMcDonaldIslands</source>
        <translation>Heard ja McDonaldinsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="272"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="273"/>
        <source>HongKong</source>
        <translation>Hongkong</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="274"/>
        <source>Hungary</source>
        <translation>Unkari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="275"/>
        <source>Iceland</source>
        <translation>Islanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="276"/>
        <source>India</source>
        <translation>Intia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="277"/>
        <source>Indonesia</source>
        <translation>Indonesia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="278"/>
        <source>Iran</source>
        <translation>Iran</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="279"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="280"/>
        <source>Ireland</source>
        <translation>Irlanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="281"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="282"/>
        <source>Italy</source>
        <translation>Italia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="283"/>
        <source>Jamaica</source>
        <translation>Jamaika</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="284"/>
        <source>Japan</source>
        <translation>Japani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="285"/>
        <source>Jordan</source>
        <translation>Jordania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="286"/>
        <source>Kazakhstan</source>
        <translation>Kazakstan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="287"/>
        <source>Kenya</source>
        <translation>Kenia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="288"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="289"/>
        <source>DemocraticRepublicOfKorea</source>
        <translation>Korean Demokraattinen Kansantasavalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="290"/>
        <source>RepublicOfKorea</source>
        <translation>Korean Tasavalta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="291"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="292"/>
        <source>Kyrgyzstan</source>
        <translation>Kirgisia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="293"/>
        <source>Lao</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="294"/>
        <source>Latvia</source>
        <translation>Latvia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="295"/>
        <source>Lebanon</source>
        <translation>Libanon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="296"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="297"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="298"/>
        <source>LibyanArabJamahiriya</source>
        <translation>Libya</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="299"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="300"/>
        <source>Lithuania</source>
        <translation>Liettua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="301"/>
        <source>Luxembourg</source>
        <translation>Luxemburg</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="302"/>
        <source>Macau</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="303"/>
        <source>Macedonia</source>
        <translation>Makedonia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="304"/>
        <source>Madagascar</source>
        <translation>Madagaskar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="305"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="306"/>
        <source>Malaysia</source>
        <translation>Malesia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="307"/>
        <source>Maldives</source>
        <translation>Malediivit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="308"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="309"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="310"/>
        <source>MarshallIslands</source>
        <translation>Marshallinsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="311"/>
        <source>Martinique</source>
        <translation>Martinique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="312"/>
        <source>Mauritania</source>
        <translation>Mauritania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="313"/>
        <source>Mauritius</source>
        <translation>Mauritius</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="314"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="315"/>
        <source>Mexico</source>
        <translation>Meksiko</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="316"/>
        <source>Micronesia</source>
        <translation>Mikronesian Liittovaltio</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="317"/>
        <source>Moldova</source>
        <translation>Moldova</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="318"/>
        <source>Monaco</source>
        <translation>Monaco</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="319"/>
        <source>Mongolia</source>
        <translation>Mongolia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="320"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="321"/>
        <source>Morocco</source>
        <translation>Marokko</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="322"/>
        <source>Mozambique</source>
        <translation>Mosambik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="323"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="324"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="325"/>
        <source>NauruCountry</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="326"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="327"/>
        <source>Netherlands</source>
        <translation>Alankomaat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="328"/>
        <source>NetherlandsAntilles</source>
        <translation>Alankomaiden Antillit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="329"/>
        <source>NewCaledonia</source>
        <translation>Uusi-Kaledonia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="330"/>
        <source>NewZealand</source>
        <translation>Uusi-Seelanti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="331"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="332"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="333"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="334"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="335"/>
        <source>NorfolkIsland</source>
        <translation>Norfolkinsaari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="336"/>
        <source>NorthernMarianaIslands</source>
        <translation>Pohjois-Mariaanit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="337"/>
        <source>Norway</source>
        <translation>Norja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="338"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="339"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="340"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="341"/>
        <source>PalestinianTerritory</source>
        <translation>Palestiina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="342"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="343"/>
        <source>PapuaNewGuinea</source>
        <translation>Papua-Uusi-Guinea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="344"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="345"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="346"/>
        <source>Philippines</source>
        <translation>Filippiinit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="347"/>
        <source>Pitcairn</source>
        <translation>Pitcairn</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="348"/>
        <source>Poland</source>
        <translation>Puola</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="349"/>
        <source>Portugal</source>
        <translation>Portugali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="350"/>
        <source>PuertoRico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="351"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="352"/>
        <source>Reunion</source>
        <translation>Réunion</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="353"/>
        <source>Romania</source>
        <translation>Romania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="354"/>
        <source>RussianFederation</source>
        <translation>Venäjä</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="355"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="356"/>
        <source>SaintKittsAndNevis</source>
        <translation>Saint Kitts ja Nevis</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="357"/>
        <source>StLucia</source>
        <translation>Saint Lucia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="358"/>
        <source>StVincentAndTheGrenadines</source>
        <translation>Saint Vincent ja Grenadiinit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="359"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="360"/>
        <source>SanMarino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="361"/>
        <source>SaoTomeAndPrincipe</source>
        <translation>São Tomé ja Príncipe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="362"/>
        <source>SaudiArabia</source>
        <translation>Saudi-Arabia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="363"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="364"/>
        <source>Seychelles</source>
        <translation>Seychellit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="365"/>
        <source>SierraLeone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="366"/>
        <source>Singapore</source>
        <translation>Singapore</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="367"/>
        <source>Slovakia</source>
        <translation>Slovakia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="368"/>
        <source>Slovenia</source>
        <translation>Slovenia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="369"/>
        <source>SolomonIslands</source>
        <translation>Salomonsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="370"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="371"/>
        <source>SouthAfrica</source>
        <translation>Etelä-Afrikka</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="372"/>
        <source>SouthGeorgiaAndTheSouthSandwichIslands</source>
        <translation>Etelä-Georgia ja Eteläiset Sandwichsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="373"/>
        <source>Spain</source>
        <translation>Espanja</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="374"/>
        <source>SriLanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="375"/>
        <source>StHelena</source>
        <translation>Saint Helena</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="376"/>
        <source>StPierreAndMiquelon</source>
        <translation>Saint-Pierre ja Miquelon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="377"/>
        <source>Sudan</source>
        <translation></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="378"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="379"/>
        <source>SvalbardAndJanMayenIslands</source>
        <translation>Svalbard ja Jan Mayen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="380"/>
        <source>Swaziland</source>
        <translation>Swazimaa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="381"/>
        <source>Sweden</source>
        <translation>Ruotsi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="382"/>
        <source>Switzerland</source>
        <translation>Sveitsi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="383"/>
        <source>SyrianArabRepublic</source>
        <translation>Syyria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="384"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="385"/>
        <source>Tajikistan</source>
        <translation>Tadžikistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="386"/>
        <source>Tanzania</source>
        <translation>Tansania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="387"/>
        <source>Thailand</source>
        <translation>Thaimaa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="388"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="389"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="390"/>
        <source>TongaCountry</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="391"/>
        <source>TrinidadAndTobago</source>
        <translation>Trinidad ja Tobago</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="392"/>
        <source>Tunisia</source>
        <translation>Tunisia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="393"/>
        <source>Turkey</source>
        <translation>Turkki</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="394"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="395"/>
        <source>TurksAndCaicosIslands</source>
        <translation>Turks- ja Caicossaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="396"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="397"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="398"/>
        <source>Ukraine</source>
        <translation>Ukraina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="399"/>
        <source>UnitedArabEmirates</source>
        <translation>Arabiemiirikunnat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="400"/>
        <source>UnitedKingdom</source>
        <translation>Yhdistynyt Kuningaskunta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="401"/>
        <source>UnitedStates</source>
        <translation>Yhdysvallat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="402"/>
        <source>UnitedStatesMinorOutlyingIslands</source>
        <translation>Yhdysvaltain Tyynenmeren Erillissaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="403"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="404"/>
        <source>Uzbekistan</source>
        <translation>Uzbekistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="405"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="406"/>
        <source>VaticanCityState</source>
        <translation>Vatikaanivaltio</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="407"/>
        <source>Venezuela</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="408"/>
        <source>VietNam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="409"/>
        <source>BritishVirginIslands</source>
        <translation>Brittiläiset Neitsytsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="410"/>
        <source>USVirginIslands</source>
        <translation>Yhdysvaltain Neitsytsaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="411"/>
        <source>WallisAndFutunaIslands</source>
        <translation>Wallis ja Futunasaaret</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="412"/>
        <source>WesternSahara</source>
        <translation>Länsi-Sahara</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="413"/>
        <source>Yemen</source>
        <translation>Jemen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="414"/>
        <source>Yugoslavia</source>
        <translation>Jugoslavia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="415"/>
        <source>Zambia</source>
        <translation>Sambia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="416"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
</context>
<context>
    <name>QxtCommandOptions</name>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="32"/>
        <source>sets the application GUI style</source>
        <translation>asettaa applikaation GUI-tyylin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="33"/>
        <source>sets the application stylesheet</source>
        <translation>asettaa applikaation tyyliohjeet</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="34"/>
        <source>restores the application from an earlier session</source>
        <translation>palauttaa applikaation aiemmasta istunnosta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="35"/>
        <source>displays debugging information about widgets</source>
        <translation>näyttää debug-informaatiota widgeteistä</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="36"/>
        <source>use right-to-left layout</source>
        <translation>käytä asettelua oikealta vasemmalle</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="38"/>
        <source>never grab the mouse or keyboard</source>
        <translation>hiirtä tai näppäimistöä ei ikinä siepata</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="41"/>
        <source>grab the mouse/keyboard even in a debugger</source>
        <translation>sieppaa hiiri/näppäimistö myös debuggerissa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="42"/>
        <source>run in synchronous mode for debugging</source>
        <translation>aja synkronisessa debuggaus-tilassa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="45"/>
        <source>use Direct3D by default</source>
        <translation>käytä oletuksena Direct3D:tä</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="48"/>
        <source>sets the X11 display</source>
        <translation>asettaa X11 näytön</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="49"/>
        <source>sets the geometry of the first window</source>
        <translation>asettaa ensimmäisen ikkunan geometrian</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="51"/>
        <source>sets the default font</source>
        <translation>asettaa oletusfontin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="53"/>
        <source>sets the default background color</source>
        <translation>asettaa oletustaustavärin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="55"/>
        <source>sets the default foreground color</source>
        <translation>asettaa oletusvärin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="57"/>
        <source>sets the default button color</source>
        <translation>asettaa painikkeen oletusvärin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="58"/>
        <source>sets the application name</source>
        <translation>asettaa applikaation nimen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="59"/>
        <source>sets the application title</source>
        <translation>asettaa applikaation otsikon</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="60"/>
        <source>sets the X11 visual type</source>
        <translation>asettaa X11 visual tyypin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="61"/>
        <source>limit the number of colors on an 8-bit display</source>
        <translation>rajoittaa värien määrän 8-bittisellä näytöllä</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="62"/>
        <source>use a private color map</source>
        <translation>käytä privaattia värikarttaa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="63"/>
        <source>sets the input method server</source>
        <translation>asettaa input method palvelimen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="64"/>
        <source>disable the X Input Method</source>
        <translation>disabloi X Input Method</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="65"/>
        <source>sets the style used by the input method</source>
        <translation>asettaa input metodin käyttämän tyylin</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="289"/>
        <source>Short options cannot have optional parameters</source>
        <translation>Lyhyillä optioilla ei voi olla valinnaisia parametreja</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="300"/>
        <source>positional() called before parse()</source>
        <translation>positional() kutsuttu ennen parse():a</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="356"/>
        <source>unrecognized() called before parse()</source>
        <translation>unrecognized() kutsuttu ennen parse():a</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="325"/>
        <source>count() called before parse()</source>
        <translation>count() kutsuttu ennen parsea():a</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="342"/>
        <source>value() called before parse()</source>
        <translation>value() kutsuttu ennen parse():a</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="581"/>
        <source>unrecognized parameters: </source>
        <translation>tuntemattomia parametreja:</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="584"/>
        <source>%1 requires a parameter</source>
        <translation>%1 vaatii parametrin</translation>
    </message>
</context>
<context>
    <name>QxtCommandOptionsPrivate</name>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="164"/>
        <source>option &quot;%1&quot; not found</source>
        <translation>optio &quot;%1&quot; ei löytynyt</translation>
    </message>
</context>
<context>
    <name>QxtConfigDialog</name>
    <message>
        <location filename="../src/gui/qxtconfigdialog.cpp" line="132"/>
        <source>&amp;OK</source>
        <translation>&amp;OK</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtconfigdialog.cpp" line="133"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Peruuta</translation>
    </message>
</context>
<context>
    <name>QxtConfirmationMessage</name>
    <message>
        <location filename="../src/gui/qxtconfirmationmessage.cpp" line="74"/>
        <source>Do not show again.</source>
        <translation>Älä näytä uudelleen.</translation>
    </message>
</context>
<context>
    <name>QxtCountryComboBox</name>
    <message>
        <location filename="../src/gui/qxtcountrycombobox.cpp" line="109"/>
        <source>DESIGNER MODE  -  DESIGNER MODE</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QxtCountryModel</name>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Nimi</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="207"/>
        <source>ISO 3166 Alpha 2</source>
        <translation>ISO 3166 Alpha 2</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="209"/>
        <source>QLocale</source>
        <translation>QLocale</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="211"/>
        <source>ISO 3166 Alpha 3</source>
        <translation>ISO 3166 Alpha 3</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="213"/>
        <source>Currency</source>
        <translation>Valuutta</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="215"/>
        <source>Currency Code</source>
        <translation>Valuuttakoodi</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="217"/>
        <source>Currency Symbol</source>
        <translation>Valuuttasymboli</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="219"/>
        <source>Continent</source>
        <translation>Maanosa</translation>
    </message>
</context>
<context>
    <name>QxtLocale</name>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="766"/>
        <source>*No Currency*</source>
        <translation>*Ei Valuuttaa*</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="767"/>
        <source>Afghani</source>
        <translation>Afganistanin Afgani</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="768"/>
        <source>Algerian Dinar</source>
        <translation>Algerian Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="769"/>
        <source>Argentine Peso</source>
        <translation>Argentiinan Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="770"/>
        <source>Armenian Dram</source>
        <translation>Armenian Dram</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="771"/>
        <source>Aruban Guilder</source>
        <translation>Aruban Guldeni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="772"/>
        <source>Australian Dollar</source>
        <translation>Australian Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="773"/>
        <source>Azerbaijanian Manat</source>
        <translation>Azerbaidžanin Manat</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="774"/>
        <source>Bahamian Dollar</source>
        <translation>Bahaman Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="775"/>
        <source>Bahraini Dinar</source>
        <translation>Bahrainin Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="776"/>
        <source>Baht</source>
        <translation>Thaimaan Baht</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="777"/>
        <source>Balboa</source>
        <translation>Panaman Balboa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="778"/>
        <source>Barbados Dollar</source>
        <translation>Barbadoksen Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="779"/>
        <source>Belarussian Ruble</source>
        <translation>Valko-Venäjän Rupla</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="780"/>
        <source>Belize Dollar</source>
        <translation>Belizen Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="781"/>
        <source>Bermudian Dollar</source>
        <translation>Bermudan Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="782"/>
        <source>Bolivar Fuerte</source>
        <translation>Venezuelan bolivar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="783"/>
        <source>Boliviano</source>
        <translation>Bolivian Boliviano</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="784"/>
        <source>Brazilian Real</source>
        <translation>Brasilian Real</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="785"/>
        <source>Brunei Dollar</source>
        <translation>Brunein Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="786"/>
        <source>Bulgarian Lev</source>
        <translation>Bulgarian Leva</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="787"/>
        <source>Burundi Franc</source>
        <translation>Burundin Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="788"/>
        <source>CFA Franc BCEAO</source>
        <translation>CFA-frangi BCEAO</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="789"/>
        <source>CFA Franc BEAC</source>
        <translation>CFA-frangi BEAC</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="790"/>
        <source>CFP Franc</source>
        <translation>CFP-frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="791"/>
        <source>Canadian Dollar</source>
        <translation>Kanadan Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="792"/>
        <source>Cape Verde Escudo</source>
        <translation>Kap Verden Escudo</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="793"/>
        <source>Cayman Islands Dollar</source>
        <translation>Caymansaarten Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="794"/>
        <source>Chilean Peso</source>
        <translation>Chilen Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="795"/>
        <source>Colombian Peso</source>
        <translation>Kolumbian Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="796"/>
        <source>Comoro Franc</source>
        <translation>Komorien Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="797"/>
        <source>Convertible Marks</source>
        <translation>Bosnia ja Hertsegovinan Vaihdettava Markka</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="798"/>
        <source>Cordoba Oro</source>
        <translation>Nicaraguan Córdoba Oro</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="799"/>
        <source>Costa Rican Colon</source>
        <translation>Costa Rican Colón</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="800"/>
        <source>Croatian Kuna</source>
        <translation>Kroatian Kuna</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="801"/>
        <source>Cuban Peso</source>
        <translation>Kuuban Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="802"/>
        <source>Cyprus Pound</source>
        <translation>Kyproksen Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="803"/>
        <source>Czech Koruna</source>
        <translation>Tšekin Koruna</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="804"/>
        <source>Dalasi</source>
        <translation>Gambian Dalasi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="805"/>
        <source>Danish Krone</source>
        <translation>Tanskan Kruunu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="806"/>
        <source>Denar</source>
        <translation>Makedonian dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="807"/>
        <source>Djibouti Franc</source>
        <translation>Djiboutin Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="808"/>
        <source>Dobra</source>
        <translation>Sao Tomén ja Príncipen Dobra</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="809"/>
        <source>Dominican Peso</source>
        <translation>Dominikaanisen Tasavallan Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="810"/>
        <source>Dong</source>
        <translation>Vietnamin đồng</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="811"/>
        <source>East Caribbean Dollar</source>
        <translation>Itä-Karibian Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="812"/>
        <source>Egyptian Pound</source>
        <translation>Egyptin Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="813"/>
        <source>El Salvador Colon</source>
        <translation>El Salvadorin Colón</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="814"/>
        <source>Ethiopian Birr</source>
        <translation>Etiopian Birr</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="815"/>
        <source>Euro</source>
        <translation>Euro</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="816"/>
        <source>Falkland Islands Pound</source>
        <translation>Falklandinsaarten Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="817"/>
        <source>Fiji Dollar</source>
        <translation>Fidžin Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="818"/>
        <source>Forint</source>
        <translation>Unkarin Forintti</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="819"/>
        <source>Franc Congolais</source>
        <translation>Kongon Demokraattisen Tasavallan Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="820"/>
        <source>Ghana Cedi</source>
        <translation>Ghanan Cedi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="821"/>
        <source>Gibraltar Pound</source>
        <translation>Gibraltarin Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="822"/>
        <source>Gourde</source>
        <translation>Haitin Gourde</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="823"/>
        <source>Guarani</source>
        <translation>Paraguayn Guarani</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="824"/>
        <source>Guinea-Bissau Peso</source>
        <translation>Guinea-Bissaun Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="825"/>
        <source>Guinea Franc</source>
        <translation>Guinean Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="826"/>
        <source>Guyana Dollar</source>
        <translation>Guyanan Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="827"/>
        <source>Hong Kong Dollar</source>
        <translation>Hongkongin Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="828"/>
        <source>Hryvnia</source>
        <translation>Ukrainan Hryvnja</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="829"/>
        <source>Iceland Krona</source>
        <translation>Islannin Kruunu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="830"/>
        <source>Indian Rupee</source>
        <translation>Intian Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="831"/>
        <source>Iranian Rial</source>
        <translation>Iranin Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="832"/>
        <source>Iraqi Dinar</source>
        <translation>Irakin Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="833"/>
        <source>Jamaican Dollar</source>
        <translation>Jamaikan Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="834"/>
        <source>Jordanian Dinar</source>
        <translation>Jordanian Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="835"/>
        <source>Kenyan Shilling</source>
        <translation>Kenian Šillinki</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="836"/>
        <source>Kina</source>
        <translation>Papua-Uuden-Guinean Kina</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="837"/>
        <source>Kip</source>
        <translation>Laosin Kip</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="838"/>
        <source>Kroon</source>
        <translation>Viron Kruunu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="839"/>
        <source>Kuwaiti Dinar</source>
        <translation>Kuwaitin Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="840"/>
        <source>Kwacha</source>
        <translation type="obsolete">Malawin Kwacha</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="840"/>
        <source>Kwanza</source>
        <translation>Angolan Kwanza</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="841"/>
        <source>Kyat</source>
        <translation>Myanmarin Kyat</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="842"/>
        <source>Lari</source>
        <translation>Georgian Lari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="843"/>
        <source>Latvian Lats</source>
        <translation>Latvian Lati</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="844"/>
        <source>Lebanese Pound</source>
        <translation>Libanonin Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="845"/>
        <source>Lek</source>
        <translation>Albanian Lek</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="846"/>
        <source>Lempira</source>
        <translation>Hondurasin Lempira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="847"/>
        <source>Leone</source>
        <translation>Sierra Leonen Leone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="848"/>
        <source>Liberian Dollar</source>
        <translation>Liberian Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="849"/>
        <source>Libyan Dinar</source>
        <translation>Libyan Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="850"/>
        <source>Lilangeni</source>
        <translation>Swazimaan Lilangeni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="851"/>
        <source>Lithuanian Litas</source>
        <translation>Liettuan Liti</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="852"/>
        <source>Loti</source>
        <translation>Lesothon Loti</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="853"/>
        <source>Malagasy Ariary</source>
        <translation>Madagaskarin Ariary</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="855"/>
        <source>Malaysian Ringgit</source>
        <translation>Malesian Ringgit</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="856"/>
        <source>Maltese Lira</source>
        <translation>Maltan Liira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="857"/>
        <source>Manat</source>
        <translation>Turkmenistanin Manat</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="858"/>
        <source>Mauritius Rupee</source>
        <translation>Mauritiuksen Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="859"/>
        <source>Metical</source>
        <translation>Mosambikin Metical</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="860"/>
        <source>Mexican Peso</source>
        <translation>Meksikon Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="861"/>
        <source>Mexican Unidad de Inversion</source>
        <translation>Meksikon Unidad de Inversion</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="862"/>
        <source>Moldovan Leu</source>
        <translation>Moldovan Leu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="863"/>
        <source>Moroccan Dirham</source>
        <translation>Marokon Dirhami</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="864"/>
        <source>Mvdol</source>
        <translation>Bolivian Mvdol</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="865"/>
        <source>Naira</source>
        <translation>Nigerian Naira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="866"/>
        <source>Nakfa</source>
        <translation>Eritrean Nakfa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="867"/>
        <source>Namibia Dollar</source>
        <translation>Namibian Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="868"/>
        <source>Nepalese Rupee</source>
        <translation>Nepalin Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="869"/>
        <source>Netherlands Antillian Guilder</source>
        <translation>Alankomaiden Antillien Guldeni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="870"/>
        <source>New Israeli Sheqel</source>
        <translation>Uusi Israelin Sekeli</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="871"/>
        <source>New Leu</source>
        <translation>Romanian New Leu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="872"/>
        <source>New Taiwan Dollar</source>
        <translation>Uusi Taiwanin Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="873"/>
        <source>New Turkish Lira</source>
        <translation>Uusi Turkin Liira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="874"/>
        <source>New Zealand Dollar</source>
        <translation>Uuden Seelannin Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="875"/>
        <source>Ngultrum</source>
        <translation>Bhutanin Ngultrum</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="876"/>
        <source>North Korean Won</source>
        <translation>Pohjois-Korean Won</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="877"/>
        <source>Norwegian Krone</source>
        <translation>Norjan Kruunu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="878"/>
        <source>Nuevo Sol</source>
        <translation>Perun Nuevo Sol</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="879"/>
        <source>Ouguiya</source>
        <translation>Mauritanian Ouguiya</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="880"/>
        <source>Pa&apos;anga</source>
        <translation>Pa&apos;anga</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="881"/>
        <source>Pakistan Rupee</source>
        <translation>Pakistanin Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="882"/>
        <source>Pataca</source>
        <translation>Macaon Pataca</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="883"/>
        <source>Peso Uruguayo</source>
        <translation>Uruguayn Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="884"/>
        <source>Philippine Peso</source>
        <translation>Filippiinien Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="885"/>
        <source>Pound Sterling</source>
        <translation>Englannin Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="886"/>
        <source>Pula</source>
        <translation>Botswanan Pula</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="887"/>
        <source>Qatari Rial</source>
        <translation>Qatarin Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="888"/>
        <source>Quetzal</source>
        <translation>Guatemalan Quetzal</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="889"/>
        <source>Rand</source>
        <translation>Etelä-Afrikan Randi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="890"/>
        <source>Rial Omani</source>
        <translation>Omanin Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="891"/>
        <source>Riel</source>
        <translation>Kambodžan Riel</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="892"/>
        <source>Rufiyaa</source>
        <translation>Malediivien Rufiyaa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="893"/>
        <source>Rupiah</source>
        <translation>Indonesian Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="894"/>
        <source>Russian Ruble</source>
        <translation>Venäjän Rupla</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="895"/>
        <source>Rwanda Franc</source>
        <translation>Ruandan Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="896"/>
        <source>Saint Helena Pound</source>
        <translation>Saint Helenan Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="897"/>
        <source>Saudi Riyal</source>
        <translation>Saudi-Arabian Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="898"/>
        <source>Serbian Dinar</source>
        <translation>Serbian Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="899"/>
        <source>Seychelles Rupee</source>
        <translation>Seychellien Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="900"/>
        <source>Singapore Dollar</source>
        <translation>Singaporen Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="901"/>
        <source>Slovak Koruna</source>
        <translation>Slovakian Koruna</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="902"/>
        <source>Solomon Islands Dollar</source>
        <translation>Salomonsaarten Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="903"/>
        <source>Som</source>
        <translation>Kirgisian Som</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="904"/>
        <source>Somali Shilling</source>
        <translation>Somalian Šillinki</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="905"/>
        <source>Somoni</source>
        <translation>Tadžikistanin Somoni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="906"/>
        <source>Sri Lanka Rupee</source>
        <translation>Sri Lankan Rupia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="907"/>
        <source>Sudanese Pound</source>
        <translation>Sudanin Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="908"/>
        <source>Surinam Dollar</source>
        <translation>Surinamin Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="909"/>
        <source>Swedish Krona</source>
        <translation>Ruotsin Kruunu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="910"/>
        <source>Swiss Franc</source>
        <translation>Sveitsin Frangi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="911"/>
        <source>Syrian Pound</source>
        <translation>Syyrian Punta</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="912"/>
        <source>Taka</source>
        <translation>Bangladeshin Taka</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="913"/>
        <source>Tala</source>
        <translation>Samoan Tala</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="914"/>
        <source>Tanzanian Shilling</source>
        <translation>Tansanian Šillinki</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="915"/>
        <source>Tenge</source>
        <translation>Kazakstanin Tenge</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="916"/>
        <source>Trinidad and Tobago Dollar</source>
        <translation>Trinidadin ja Tobagon Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="917"/>
        <source>Tugrik</source>
        <translation>Mongolian Tukrik</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="918"/>
        <source>Tunisian Dinar</source>
        <translation>Tunisian Dinaari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="919"/>
        <source>UAE Dirham</source>
        <translation>Arabiemiirikuntien Dirhami</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="920"/>
        <source>US Dollar</source>
        <translation>Yhdysvaltain Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="921"/>
        <source>Uganda Shilling</source>
        <translation>Ugandan Šillinki</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="922"/>
        <source>Unidad de Valor Real</source>
        <translation>Kolumbian Unidad de Valor Real</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="923"/>
        <source>Unidades de fomento</source>
        <translation>Chilen Unidades de fomento</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="924"/>
        <source>Uruguay Peso en Unidades Indexadas</source>
        <translation>Uruguayn Peso en Unidades Indexadas</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="925"/>
        <source>Uzbekistan Sum</source>
        <translation>Uzbekistanin Sum</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="926"/>
        <source>Vatu</source>
        <translation>Vanuatun Vatu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="927"/>
        <source>Won</source>
        <translation>Etelä-Korean Won</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="928"/>
        <source>Yemeni Rial</source>
        <translation>Jemenin Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="929"/>
        <source>Yen</source>
        <translation>Japanin Jeni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="930"/>
        <source>Yuan Renminbi</source>
        <translation>Kiinan Kansantasavallan Yuan Renminbi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="932"/>
        <source>Zimbabwe Dollar</source>
        <translation>Zimbabwen Dollari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="933"/>
        <source>Zloty</source>
        <translation>Puolan Zloty</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1279"/>
        <source>NorthAmerica</source>
        <translation>Pohjois-Amerikka</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1280"/>
        <source>SouthAmerica</source>
        <translation>Etelä-Amerikka</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1281"/>
        <source>Europe</source>
        <translation>Eurooppa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1282"/>
        <source>Africa</source>
        <translation>Afrikka</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1283"/>
        <source>Asia</source>
        <translation>Aasia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1284"/>
        <source>Australia</source>
        <translation>Australia</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1285"/>
        <source>Antarctica</source>
        <translation>Antarktis</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="854"/>
        <source>MalawiKwacha</source>
        <translation>Malawin Kwacha</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="931"/>
        <source>ZambiaKwacha</source>
        <translation>Zambian Kwacha</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1278"/>
        <source>None</source>
        <translation>Ei mikään</translation>
    </message>
</context>
<context>
    <name>QxtProgressLabel</name>
    <message>
        <location filename="../src/gui/qxtprogresslabel.cpp" line="236"/>
        <source>mm:ss</source>
        <translation>mm:ss</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtprogresslabel.cpp" line="239"/>
        <source>ETA: %r</source>
        <translation>ETA: %r</translation>
    </message>
</context>
</TS>
