<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="fr">
<context>
    <name>QLocale</name>
    <message>
        <location filename="gen_qlocale.cpp" line="49"/>
        <source>German</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="8"/>
        <source>C</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="9"/>
        <source>Abkhazian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="10"/>
        <source>Afan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="11"/>
        <source>Afar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="12"/>
        <source>Afrikaans</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="13"/>
        <source>Albanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="14"/>
        <source>Amharic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="15"/>
        <source>Arabic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="16"/>
        <source>Armenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="17"/>
        <source>Assamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="18"/>
        <source>Aymara</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="19"/>
        <source>Azerbaijani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="20"/>
        <source>Bashkir</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="21"/>
        <source>Basque</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="22"/>
        <source>Bengali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="23"/>
        <source>Bhutani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="24"/>
        <source>Bihari</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="25"/>
        <source>Bislama</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="26"/>
        <source>Breton</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="27"/>
        <source>Bulgarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="28"/>
        <source>Burmese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="29"/>
        <source>Byelorussian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="30"/>
        <source>Cambodian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="31"/>
        <source>Catalan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="32"/>
        <source>Chinese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="33"/>
        <source>Corsican</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="34"/>
        <source>Croatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="35"/>
        <source>Czech</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="36"/>
        <source>Danish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="37"/>
        <source>Dutch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="38"/>
        <source>English</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="39"/>
        <source>Esperanto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="40"/>
        <source>Estonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="41"/>
        <source>Faroese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="42"/>
        <source>FijiLanguage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="43"/>
        <source>Finnish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="44"/>
        <source>French</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="45"/>
        <source>Frisian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="46"/>
        <source>Gaelic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="47"/>
        <source>Galician</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="48"/>
        <source>Georgian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="50"/>
        <source>Greek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="51"/>
        <source>Greenlandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="52"/>
        <source>Guarani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="53"/>
        <source>Gujarati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="54"/>
        <source>Hausa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="55"/>
        <source>Hebrew</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="56"/>
        <source>Hindi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="57"/>
        <source>Hungarian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="58"/>
        <source>Icelandic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="59"/>
        <source>Indonesian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="60"/>
        <source>Interlingua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="61"/>
        <source>Interlingue</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="62"/>
        <source>Inuktitut</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="63"/>
        <source>Inupiak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="64"/>
        <source>Irish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="65"/>
        <source>Italian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="66"/>
        <source>Japanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="67"/>
        <source>Javanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="68"/>
        <source>Kannada</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="69"/>
        <source>Kashmiri</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="70"/>
        <source>Kazakh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="71"/>
        <source>Kinyarwanda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="72"/>
        <source>Kirghiz</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="73"/>
        <source>Korean</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="74"/>
        <source>Kurdish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="75"/>
        <source>Kurundi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="76"/>
        <source>Laothian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="77"/>
        <source>Latin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="78"/>
        <source>Latvian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="79"/>
        <source>Lingala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="80"/>
        <source>Lithuanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="81"/>
        <source>Macedonian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="82"/>
        <source>Malagasy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="83"/>
        <source>Malay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="84"/>
        <source>Malayalam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="85"/>
        <source>Maltese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="86"/>
        <source>Maori</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="87"/>
        <source>Marathi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="88"/>
        <source>Moldavian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="89"/>
        <source>Mongolian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="90"/>
        <source>NauruLanguage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="91"/>
        <source>Nepali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="92"/>
        <source>Norwegian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="93"/>
        <source>NorwegianBokmal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="94"/>
        <source>Occitan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="95"/>
        <source>Oriya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="96"/>
        <source>Pashto</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="97"/>
        <source>Persian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="98"/>
        <source>Polish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="99"/>
        <source>Portuguese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="100"/>
        <source>Punjabi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="101"/>
        <source>Quechua</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="102"/>
        <source>RhaetoRomance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="103"/>
        <source>Romanian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="104"/>
        <source>Russian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="105"/>
        <source>Samoan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="106"/>
        <source>Sangho</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="107"/>
        <source>Sanskrit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="108"/>
        <source>Serbian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="109"/>
        <source>SerboCroatian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="110"/>
        <source>Sesotho</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="111"/>
        <source>Setswana</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="112"/>
        <source>Shona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="113"/>
        <source>Sindhi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="114"/>
        <source>Singhalese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="115"/>
        <source>Siswati</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="116"/>
        <source>Slovak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="117"/>
        <source>Slovenian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="118"/>
        <source>Somali</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="119"/>
        <source>Spanish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="120"/>
        <source>Sundanese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="121"/>
        <source>Swahili</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="122"/>
        <source>Swedish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="123"/>
        <source>Tagalog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="124"/>
        <source>Tajik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="125"/>
        <source>Tamil</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="126"/>
        <source>Tatar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="127"/>
        <source>Telugu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="128"/>
        <source>Thai</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="129"/>
        <source>Tibetan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="130"/>
        <source>Tigrinya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="131"/>
        <source>TongaLanguage</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="132"/>
        <source>Tsonga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="133"/>
        <source>Turkish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="134"/>
        <source>Turkmen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="135"/>
        <source>Twi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="136"/>
        <source>Uigur</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="137"/>
        <source>Ukrainian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="138"/>
        <source>Urdu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="139"/>
        <source>Uzbek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="140"/>
        <source>Vietnamese</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="141"/>
        <source>Volapuk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="142"/>
        <source>Welsh</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="143"/>
        <source>Wolof</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="144"/>
        <source>Xhosa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="145"/>
        <source>Yiddish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="146"/>
        <source>Yoruba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="147"/>
        <source>Zhuang</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="148"/>
        <source>Zulu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="149"/>
        <source>NorwegianNynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="150"/>
        <source>Nynorsk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="151"/>
        <source>Bosnian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="152"/>
        <source>Divehi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="153"/>
        <source>Manx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="154"/>
        <source>Cornish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="155"/>
        <source>Akan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="156"/>
        <source>Konkani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="157"/>
        <source>Ga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="158"/>
        <source>Igbo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="159"/>
        <source>Kamba</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="160"/>
        <source>Syriac</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="161"/>
        <source>Blin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="162"/>
        <source>Geez</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="163"/>
        <source>Koro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="164"/>
        <source>Sidamo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="165"/>
        <source>Atsam</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="166"/>
        <source>Tigre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="167"/>
        <source>Jju</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="168"/>
        <source>Friulian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="169"/>
        <source>Venda</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="170"/>
        <source>Ewe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="171"/>
        <source>Walamo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="172"/>
        <source>Hawaiian</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="173"/>
        <source>Tyap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="176"/>
        <source>AnyCountry</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="177"/>
        <source>Afghanistan</source>
        <translation>Afghanistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="178"/>
        <source>Albania</source>
        <translation>Albanie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="179"/>
        <source>Algeria</source>
        <translation>Algérie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="180"/>
        <source>AmericanSamoa</source>
        <translation>Samoa américaines</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="181"/>
        <source>Andorra</source>
        <translation>Andorre</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="182"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="183"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="184"/>
        <source>Antarctica</source>
        <translation>Antarctique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="185"/>
        <source>AntiguaAndBarbuda</source>
        <translation>Antigua-et-Barbuda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="186"/>
        <source>Argentina</source>
        <translation>Argentine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="187"/>
        <source>Armenia</source>
        <translation>Arménie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="188"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="189"/>
        <source>Australia</source>
        <translation>Australie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="190"/>
        <source>Austria</source>
        <translation>Autriche</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="191"/>
        <source>Azerbaijan</source>
        <translation>Azerbaïdjan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="192"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="193"/>
        <source>Bahrain</source>
        <translation>Bahreïn</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="194"/>
        <source>Bangladesh</source>
        <translation>Bangladesh</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="195"/>
        <source>Barbados</source>
        <translation>Barbade</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="196"/>
        <source>Belarus</source>
        <translation>Biélorussie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="197"/>
        <source>Belgium</source>
        <translation>Belgique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="198"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="199"/>
        <source>Benin</source>
        <translation>Bénin</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="200"/>
        <source>Bermuda</source>
        <translation>Bermudes</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="201"/>
        <source>Bhutan</source>
        <translation>Bhoutan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="202"/>
        <source>Bolivia</source>
        <translation>Bolivie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="203"/>
        <source>BosniaAndHerzegowina</source>
        <translation>Bosnie-Herzégovine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="204"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="205"/>
        <source>BouvetIsland</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="206"/>
        <source>Brazil</source>
        <translation>Brésil</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="207"/>
        <source>BritishIndianOceanTerritory</source>
        <translation>Territoire britannique de l&apos;océan Indien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="208"/>
        <source>BruneiDarussalam</source>
        <translation>Brunei Darussalam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="209"/>
        <source>Bulgaria</source>
        <translation>Bulgarie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="210"/>
        <source>BurkinaFaso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="211"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="212"/>
        <source>Cambodia</source>
        <translation>Cambodge</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="213"/>
        <source>Cameroon</source>
        <translation>Cameroun</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="214"/>
        <source>Canada</source>
        <translation>Canada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="215"/>
        <source>CapeVerde</source>
        <translation>Cap-Vert</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="216"/>
        <source>CaymanIslands</source>
        <translation>Îles Caïmanes</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="217"/>
        <source>CentralAfricanRepublic</source>
        <translation>République centrafricaine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="218"/>
        <source>Chad</source>
        <translation>Tchad</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="219"/>
        <source>Chile</source>
        <translation>Chili</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="220"/>
        <source>China</source>
        <translation>Chine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="221"/>
        <source>ChristmasIsland</source>
        <translation>Île Christmas </translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="222"/>
        <source>CocosIslands</source>
        <translation>Îles Cocos</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="223"/>
        <source>Colombia</source>
        <translation>Colombie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="224"/>
        <source>Comoros</source>
        <translation>Comores</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="225"/>
        <source>DemocraticRepublicOfCongo</source>
        <translation>Congo, République démocratique du</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="226"/>
        <source>PeoplesRepublicOfCongo</source>
        <translation>Congo, République du</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="227"/>
        <source>CookIslands</source>
        <translation>Îles Cook</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="228"/>
        <source>CostaRica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="229"/>
        <source>IvoryCoast</source>
        <translation>Côte d&apos;Ivoire</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="230"/>
        <source>Croatia</source>
        <translation>Croatie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="231"/>
        <source>Cuba</source>
        <translation>Cuba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="232"/>
        <source>Cyprus</source>
        <translation>Chypre</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="233"/>
        <source>CzechRepublic</source>
        <translation>Tchéquie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="234"/>
        <source>Denmark</source>
        <translation>Danemark</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="235"/>
        <source>Djibouti</source>
        <translation>Djibouti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="236"/>
        <source>Dominica</source>
        <translation>Dominique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="237"/>
        <source>DominicanRepublic</source>
        <translation>République dominicaine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="238"/>
        <source>EastTimor</source>
        <translation>Timor oriental</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="239"/>
        <source>Ecuador</source>
        <translation>Équateur</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="240"/>
        <source>Egypt</source>
        <translation>Égypte</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="241"/>
        <source>ElSalvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="242"/>
        <source>EquatorialGuinea</source>
        <translation>Guinée équatoriale</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="243"/>
        <source>Eritrea</source>
        <translation>Érythrée</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="244"/>
        <source>Estonia</source>
        <translation>Estonie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="245"/>
        <source>Ethiopia</source>
        <translation>Éthiopie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="246"/>
        <source>FalklandIslands</source>
        <translation>Îles Malouines</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="247"/>
        <source>FaroeIslands</source>
        <translation>Îles Féroé</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="248"/>
        <source>FijiCountry</source>
        <translation>Fidji</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="249"/>
        <source>Finland</source>
        <translation>Finlande</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="250"/>
        <source>France</source>
        <translation>France</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="251"/>
        <source>MetropolitanFrance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="252"/>
        <source>FrenchGuiana</source>
        <translation>Guyane française</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="253"/>
        <source>FrenchPolynesia</source>
        <translation>Polynésie française</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="254"/>
        <source>FrenchSouthernTerritories</source>
        <translation>French Southern Territories</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="255"/>
        <source>Gabon</source>
        <translation>Gabon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="256"/>
        <source>Gambia</source>
        <translation>Gambie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="257"/>
        <source>Georgia</source>
        <translation>Géorgie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="258"/>
        <source>Germany</source>
        <translation>Allemagne</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="259"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="260"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="261"/>
        <source>Greece</source>
        <translation>Grèce</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="262"/>
        <source>Greenland</source>
        <translation>Groenland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="263"/>
        <source>Grenada</source>
        <translation>Grenade</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="264"/>
        <source>Guadeloupe</source>
        <translation>Guadaloupe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="265"/>
        <source>Guam</source>
        <translation>GuamGuam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="266"/>
        <source>Guatemala</source>
        <translation>Guatémala</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="267"/>
        <source>Guinea</source>
        <translation>Guinée</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="268"/>
        <source>GuineaBissau</source>
        <translation>Guinée-Bissau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="269"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="270"/>
        <source>Haiti</source>
        <translation>Haïti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="271"/>
        <source>HeardAndMcDonaldIslands</source>
        <translation>Île Heard et îles McDonald</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="272"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="273"/>
        <source>HongKong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="274"/>
        <source>Hungary</source>
        <translation>Hongrie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="275"/>
        <source>Iceland</source>
        <translation>Islande</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="276"/>
        <source>India</source>
        <translation>Inde</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="277"/>
        <source>Indonesia</source>
        <translation>Indonésie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="278"/>
        <source>Iran</source>
        <translation>Iran</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="279"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="280"/>
        <source>Ireland</source>
        <translation>Irlande</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="281"/>
        <source>Israel</source>
        <translation>Israël</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="282"/>
        <source>Italy</source>
        <translation>Italie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="283"/>
        <source>Jamaica</source>
        <translation>Jamaïque</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="284"/>
        <source>Japan</source>
        <translation>Japon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="285"/>
        <source>Jordan</source>
        <translation>Jordanie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="286"/>
        <source>Kazakhstan</source>
        <translation>Kazakhstan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="287"/>
        <source>Kenya</source>
        <translation>Kenya</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="288"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="289"/>
        <source>DemocraticRepublicOfKorea</source>
        <translation>Corée du Nord</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="290"/>
        <source>RepublicOfKorea</source>
        <translation>Corée du Sud</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="291"/>
        <source>Kuwait</source>
        <translation>Koweït</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="292"/>
        <source>Kyrgyzstan</source>
        <translation>Kirghizistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="293"/>
        <source>Lao</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="294"/>
        <source>Latvia</source>
        <translation>Lettonie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="295"/>
        <source>Lebanon</source>
        <translation>Liban</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="296"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="297"/>
        <source>Liberia</source>
        <translation>Libéria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="298"/>
        <source>LibyanArabJamahiriya</source>
        <translation>Libye</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="299"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="300"/>
        <source>Lithuania</source>
        <translation>LituanieLituanie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="301"/>
        <source>Luxembourg</source>
        <translation>Luxembourg</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="302"/>
        <source>Macau</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="303"/>
        <source>Macedonia</source>
        <translation>Macédoine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="304"/>
        <source>Madagascar</source>
        <translation>Madagascar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="305"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="306"/>
        <source>Malaysia</source>
        <translation>Malaisie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="307"/>
        <source>Maldives</source>
        <translation>Maldives</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="308"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="309"/>
        <source>Malta</source>
        <translation>Malte</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="310"/>
        <source>MarshallIslands</source>
        <translation>Îles Marshall</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="311"/>
        <source>Martinique</source>
        <translation>Martinique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="312"/>
        <source>Mauritania</source>
        <translation>Mauritanie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="313"/>
        <source>Mauritius</source>
        <translation>Maurice</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="314"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="315"/>
        <source>Mexico</source>
        <translation>Mexique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="316"/>
        <source>Micronesia</source>
        <translation>Micronésie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="317"/>
        <source>Moldova</source>
        <translation>Moldavie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="318"/>
        <source>Monaco</source>
        <translation>Monaco</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="319"/>
        <source>Mongolia</source>
        <translation>Mongolie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="320"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="321"/>
        <source>Morocco</source>
        <translation>Maroc</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="322"/>
        <source>Mozambique</source>
        <translation>Mozambique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="323"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="324"/>
        <source>Namibia</source>
        <translation>Namibie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="325"/>
        <source>NauruCountry</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="326"/>
        <source>Nepal</source>
        <translation>Népal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="327"/>
        <source>Netherlands</source>
        <translation>Pays-Bas</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="328"/>
        <source>NetherlandsAntilles</source>
        <translation>Antilles néerlandaises</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="329"/>
        <source>NewCaledonia</source>
        <translation>Nouvelle-Calédonie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="330"/>
        <source>NewZealand</source>
        <translation>Nouvelle-Zélande</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="331"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="332"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="333"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="334"/>
        <source>Niue</source>
        <translation>Niué</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="335"/>
        <source>NorfolkIsland</source>
        <translation>Île Norfolk</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="336"/>
        <source>NorthernMarianaIslands</source>
        <translation>Îles Mariannes du Nord</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="337"/>
        <source>Norway</source>
        <translation>Norvège</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="338"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="339"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="340"/>
        <source>Palau</source>
        <translation>Palaos</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="341"/>
        <source>PalestinianTerritory</source>
        <translation>Territoires palestiniens occupés</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="342"/>
        <source>Panama</source>
        <translation>Panamá</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="343"/>
        <source>PapuaNewGuinea</source>
        <translation>Papouasie-Nouvelle-Guinée</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="344"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="345"/>
        <source>Peru</source>
        <translation>Pérou</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="346"/>
        <source>Philippines</source>
        <translation>Philippines</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="347"/>
        <source>Pitcairn</source>
        <translation>Îles Pitcairn</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="348"/>
        <source>Poland</source>
        <translation>Pologne</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="349"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="350"/>
        <source>PuertoRico</source>
        <translation>Porto Rico</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="351"/>
        <source>Qatar</source>
        <translation>Qatar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="352"/>
        <source>Reunion</source>
        <translation>La Réunion</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="353"/>
        <source>Romania</source>
        <translation>Roumanie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="354"/>
        <source>RussianFederation</source>
        <translation>Russie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="355"/>
        <source>Rwanda</source>
        <translation>Rwanda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="356"/>
        <source>SaintKittsAndNevis</source>
        <translation>Saint-Christophe-et-Niévès</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="357"/>
        <source>StLucia</source>
        <translation>Sainte-Lucie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="358"/>
        <source>StVincentAndTheGrenadines</source>
        <translation>Saint-Vincent-et-les Grenadines</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="359"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="360"/>
        <source>SanMarino</source>
        <translation>Saint-Marin</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="361"/>
        <source>SaoTomeAndPrincipe</source>
        <translation>São Tomé-et-Principe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="362"/>
        <source>SaudiArabia</source>
        <translation>Arabie saoudite</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="363"/>
        <source>Senegal</source>
        <translation>Sénégal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="364"/>
        <source>Seychelles</source>
        <translation>Seychelles</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="365"/>
        <source>SierraLeone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="366"/>
        <source>Singapore</source>
        <translation>Singapour</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="367"/>
        <source>Slovakia</source>
        <translation>Slovaquie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="368"/>
        <source>Slovenia</source>
        <translation>Slovénie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="369"/>
        <source>SolomonIslands</source>
        <translation>Îles Salomon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="370"/>
        <source>Somalia</source>
        <translation>Somalie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="371"/>
        <source>SouthAfrica</source>
        <translation>Afrique du Sud</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="372"/>
        <source>SouthGeorgiaAndTheSouthSandwichIslands</source>
        <translation>Géorgie du Sud-et-les Îles Sandwich du Sud</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="373"/>
        <source>Spain</source>
        <translation>Espagne</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="374"/>
        <source>SriLanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="375"/>
        <source>StHelena</source>
        <translation>Île Sainte-Hélène</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="376"/>
        <source>StPierreAndMiquelon</source>
        <translation>Saint-Pierre-et-Miquelon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="377"/>
        <source>Sudan</source>
        <translation>Soudan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="378"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="379"/>
        <source>SvalbardAndJanMayenIslands</source>
        <translation>Îles Svalbard-et-Jan Mayen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="380"/>
        <source>Swaziland</source>
        <translation>Swaziland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="381"/>
        <source>Sweden</source>
        <translation>Suède</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="382"/>
        <source>Switzerland</source>
        <translation>Suisse</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="383"/>
        <source>SyrianArabRepublic</source>
        <translation>Syrie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="384"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="385"/>
        <source>Tajikistan</source>
        <translation>TadjikistanTadjikistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="386"/>
        <source>Tanzania</source>
        <translation>Tanzanie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="387"/>
        <source>Thailand</source>
        <translation>Thaïlande</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="388"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="389"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="390"/>
        <source>TongaCountry</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="391"/>
        <source>TrinidadAndTobago</source>
        <translation>Trinité-et-Tobago</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="392"/>
        <source>Tunisia</source>
        <translation>Tunisie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="393"/>
        <source>Turkey</source>
        <translation>Turquie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="394"/>
        <source>Turkmenistan</source>
        <translation>Turkménistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="395"/>
        <source>TurksAndCaicosIslands</source>
        <translation>Îles Turques et Caïques </translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="396"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="397"/>
        <source>Uganda</source>
        <translation>Ouganda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="398"/>
        <source>Ukraine</source>
        <translation>Ukraine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="399"/>
        <source>UnitedArabEmirates</source>
        <translation>Émirats arabes unis</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="400"/>
        <source>UnitedKingdom</source>
        <translation>Royaume-Uni</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="401"/>
        <source>UnitedStates</source>
        <translation>États-Unis d&apos;Amérique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="402"/>
        <source>UnitedStatesMinorOutlyingIslands</source>
        <translation>United States Minor Outlying Islands</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="403"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="404"/>
        <source>Uzbekistan</source>
        <translation>Ouzbékistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="405"/>
        <source>Vanuatu</source>
        <translation>Vanuatu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="406"/>
        <source>VaticanCityState</source>
        <translation>Vatican</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="407"/>
        <source>Venezuela</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="408"/>
        <source>VietNam</source>
        <translation>Viêt Nam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="409"/>
        <source>BritishVirginIslands</source>
        <translation>Îles Vierges britanniques</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="410"/>
        <source>USVirginIslands</source>
        <translation>Îles Vierges américaines</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="411"/>
        <source>WallisAndFutunaIslands</source>
        <translation>Wallis-et-Futuna</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="412"/>
        <source>WesternSahara</source>
        <translation>Sahara occidental</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="413"/>
        <source>Yemen</source>
        <translation>Yémen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="414"/>
        <source>Yugoslavia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="415"/>
        <source>Zambia</source>
        <translation>Zambie</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="416"/>
        <source>Zimbabwe</source>
        <translation>Zimbabwe</translation>
    </message>
</context>
<context>
    <name>QxtCommandOptions</name>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="32"/>
        <source>sets the application GUI style</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="33"/>
        <source>sets the application stylesheet</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="34"/>
        <source>restores the application from an earlier session</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="35"/>
        <source>displays debugging information about widgets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="36"/>
        <source>use right-to-left layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="38"/>
        <source>never grab the mouse or keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="41"/>
        <source>grab the mouse/keyboard even in a debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="42"/>
        <source>run in synchronous mode for debugging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="45"/>
        <source>use Direct3D by default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="48"/>
        <source>sets the X11 display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="49"/>
        <source>sets the geometry of the first window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="51"/>
        <source>sets the default font</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="53"/>
        <source>sets the default background color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="55"/>
        <source>sets the default foreground color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="57"/>
        <source>sets the default button color</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="58"/>
        <source>sets the application name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="59"/>
        <source>sets the application title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="60"/>
        <source>sets the X11 visual type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="61"/>
        <source>limit the number of colors on an 8-bit display</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="62"/>
        <source>use a private color map</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="63"/>
        <source>sets the input method server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="64"/>
        <source>disable the X Input Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="65"/>
        <source>sets the style used by the input method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="289"/>
        <source>Short options cannot have optional parameters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="300"/>
        <source>positional() called before parse()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="356"/>
        <source>unrecognized() called before parse()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="325"/>
        <source>count() called before parse()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="342"/>
        <source>value() called before parse()</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="581"/>
        <source>unrecognized parameters: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="584"/>
        <source>%1 requires a parameter</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtCommandOptionsPrivate</name>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="164"/>
        <source>option &quot;%1&quot; not found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtConfigDialog</name>
    <message>
        <location filename="../src/gui/qxtconfigdialog.cpp" line="132"/>
        <source>&amp;OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtconfigdialog.cpp" line="133"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtConfirmationMessage</name>
    <message>
        <location filename="../src/gui/qxtconfirmationmessage.cpp" line="74"/>
        <source>Do not show again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtCountryComboBox</name>
    <message>
        <location filename="../src/gui/qxtcountrycombobox.cpp" line="109"/>
        <source>DESIGNER MODE  -  DESIGNER MODE</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtCountryModel</name>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="205"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="207"/>
        <source>ISO 3166 Alpha 2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="209"/>
        <source>QLocale</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="211"/>
        <source>ISO 3166 Alpha 3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="213"/>
        <source>Currency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="215"/>
        <source>Currency Code</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="217"/>
        <source>Currency Symbol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="219"/>
        <source>Continent</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtLocale</name>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="766"/>
        <source>*No Currency*</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="767"/>
        <source>Afghani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="768"/>
        <source>Algerian Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="769"/>
        <source>Argentine Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="770"/>
        <source>Armenian Dram</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="771"/>
        <source>Aruban Guilder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="772"/>
        <source>Australian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="773"/>
        <source>Azerbaijanian Manat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="774"/>
        <source>Bahamian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="775"/>
        <source>Bahraini Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="776"/>
        <source>Baht</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="777"/>
        <source>Balboa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="778"/>
        <source>Barbados Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="779"/>
        <source>Belarussian Ruble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="780"/>
        <source>Belize Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="781"/>
        <source>Bermudian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="782"/>
        <source>Bolivar Fuerte</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="783"/>
        <source>Boliviano</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="784"/>
        <source>Brazilian Real</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="785"/>
        <source>Brunei Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="786"/>
        <source>Bulgarian Lev</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="787"/>
        <source>Burundi Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="788"/>
        <source>CFA Franc BCEAO</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="789"/>
        <source>CFA Franc BEAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="790"/>
        <source>CFP Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="791"/>
        <source>Canadian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="792"/>
        <source>Cape Verde Escudo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="793"/>
        <source>Cayman Islands Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="794"/>
        <source>Chilean Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="795"/>
        <source>Colombian Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="796"/>
        <source>Comoro Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="797"/>
        <source>Convertible Marks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="798"/>
        <source>Cordoba Oro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="799"/>
        <source>Costa Rican Colon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="800"/>
        <source>Croatian Kuna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="801"/>
        <source>Cuban Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="802"/>
        <source>Cyprus Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="803"/>
        <source>Czech Koruna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="804"/>
        <source>Dalasi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="805"/>
        <source>Danish Krone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="806"/>
        <source>Denar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="807"/>
        <source>Djibouti Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="808"/>
        <source>Dobra</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="809"/>
        <source>Dominican Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="810"/>
        <source>Dong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="811"/>
        <source>East Caribbean Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="812"/>
        <source>Egyptian Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="813"/>
        <source>El Salvador Colon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="814"/>
        <source>Ethiopian Birr</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="815"/>
        <source>Euro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="816"/>
        <source>Falkland Islands Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="817"/>
        <source>Fiji Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="818"/>
        <source>Forint</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="819"/>
        <source>Franc Congolais</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="820"/>
        <source>Ghana Cedi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="821"/>
        <source>Gibraltar Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="822"/>
        <source>Gourde</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="823"/>
        <source>Guarani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="824"/>
        <source>Guinea-Bissau Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="825"/>
        <source>Guinea Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="826"/>
        <source>Guyana Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="827"/>
        <source>Hong Kong Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="828"/>
        <source>Hryvnia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="829"/>
        <source>Iceland Krona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="830"/>
        <source>Indian Rupee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="831"/>
        <source>Iranian Rial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="832"/>
        <source>Iraqi Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="833"/>
        <source>Jamaican Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="834"/>
        <source>Jordanian Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="835"/>
        <source>Kenyan Shilling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="836"/>
        <source>Kina</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="837"/>
        <source>Kip</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="838"/>
        <source>Kroon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="839"/>
        <source>Kuwaiti Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="840"/>
        <source>Kwanza</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="841"/>
        <source>Kyat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="842"/>
        <source>Lari</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="843"/>
        <source>Latvian Lats</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="844"/>
        <source>Lebanese Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="845"/>
        <source>Lek</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="846"/>
        <source>Lempira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="847"/>
        <source>Leone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="848"/>
        <source>Liberian Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="849"/>
        <source>Libyan Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="850"/>
        <source>Lilangeni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="851"/>
        <source>Lithuanian Litas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="852"/>
        <source>Loti</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="853"/>
        <source>Malagasy Ariary</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="855"/>
        <source>Malaysian Ringgit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="856"/>
        <source>Maltese Lira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="857"/>
        <source>Manat</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="858"/>
        <source>Mauritius Rupee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="859"/>
        <source>Metical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="860"/>
        <source>Mexican Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="861"/>
        <source>Mexican Unidad de Inversion</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="862"/>
        <source>Moldovan Leu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="863"/>
        <source>Moroccan Dirham</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="864"/>
        <source>Mvdol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="865"/>
        <source>Naira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="866"/>
        <source>Nakfa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="867"/>
        <source>Namibia Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="868"/>
        <source>Nepalese Rupee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="869"/>
        <source>Netherlands Antillian Guilder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="870"/>
        <source>New Israeli Sheqel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="871"/>
        <source>New Leu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="872"/>
        <source>New Taiwan Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="873"/>
        <source>New Turkish Lira</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="874"/>
        <source>New Zealand Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="875"/>
        <source>Ngultrum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="876"/>
        <source>North Korean Won</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="877"/>
        <source>Norwegian Krone</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="878"/>
        <source>Nuevo Sol</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="879"/>
        <source>Ouguiya</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="880"/>
        <source>Pa&apos;anga</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="881"/>
        <source>Pakistan Rupee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="882"/>
        <source>Pataca</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="883"/>
        <source>Peso Uruguayo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="884"/>
        <source>Philippine Peso</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="885"/>
        <source>Pound Sterling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="886"/>
        <source>Pula</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="887"/>
        <source>Qatari Rial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="888"/>
        <source>Quetzal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="889"/>
        <source>Rand</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="890"/>
        <source>Rial Omani</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="891"/>
        <source>Riel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="892"/>
        <source>Rufiyaa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="893"/>
        <source>Rupiah</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="894"/>
        <source>Russian Ruble</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="895"/>
        <source>Rwanda Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="896"/>
        <source>Saint Helena Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="897"/>
        <source>Saudi Riyal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="898"/>
        <source>Serbian Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="899"/>
        <source>Seychelles Rupee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="900"/>
        <source>Singapore Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="901"/>
        <source>Slovak Koruna</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="902"/>
        <source>Solomon Islands Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="903"/>
        <source>Som</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="904"/>
        <source>Somali Shilling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="905"/>
        <source>Somoni</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="906"/>
        <source>Sri Lanka Rupee</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="907"/>
        <source>Sudanese Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="908"/>
        <source>Surinam Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="909"/>
        <source>Swedish Krona</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="910"/>
        <source>Swiss Franc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="911"/>
        <source>Syrian Pound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="912"/>
        <source>Taka</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="913"/>
        <source>Tala</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="914"/>
        <source>Tanzanian Shilling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="915"/>
        <source>Tenge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="916"/>
        <source>Trinidad and Tobago Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="917"/>
        <source>Tugrik</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="918"/>
        <source>Tunisian Dinar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="919"/>
        <source>UAE Dirham</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="920"/>
        <source>US Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="921"/>
        <source>Uganda Shilling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="922"/>
        <source>Unidad de Valor Real</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="923"/>
        <source>Unidades de fomento</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="924"/>
        <source>Uruguay Peso en Unidades Indexadas</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="925"/>
        <source>Uzbekistan Sum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="926"/>
        <source>Vatu</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="927"/>
        <source>Won</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="928"/>
        <source>Yemeni Rial</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="929"/>
        <source>Yen</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="930"/>
        <source>Yuan Renminbi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="932"/>
        <source>Zimbabwe Dollar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="933"/>
        <source>Zloty</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1279"/>
        <source>NorthAmerica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1280"/>
        <source>SouthAmerica</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1281"/>
        <source>Europe</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1282"/>
        <source>Africa</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1283"/>
        <source>Asia</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1284"/>
        <source>Australia</source>
        <translation type="unfinished">Australie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1285"/>
        <source>Antarctica</source>
        <translation type="unfinished">Antarctique</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="854"/>
        <source>MalawiKwacha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="931"/>
        <source>ZambiaKwacha</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1278"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QxtProgressLabel</name>
    <message>
        <location filename="../src/gui/qxtprogresslabel.cpp" line="236"/>
        <source>mm:ss</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/gui/qxtprogresslabel.cpp" line="239"/>
        <source>ETA: %r</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
