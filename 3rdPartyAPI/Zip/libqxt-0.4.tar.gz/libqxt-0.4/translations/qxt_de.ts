<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="de">
<defaultcodec></defaultcodec>
<context>
    <name>QLocale</name>
    <message>
        <location filename="gen_qlocale.cpp" line="49"/>
        <source>German</source>
        <translation>Deutsch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="8"/>
        <source>C</source>
        <translation>C</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="9"/>
        <source>Abkhazian</source>
        <translation>Abchasisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="10"/>
        <source>Afan</source>
        <translation>Afan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="11"/>
        <source>Afar</source>
        <translation>Afar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="12"/>
        <source>Afrikaans</source>
        <translation>Afrikaans</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="13"/>
        <source>Albanian</source>
        <translation>Albanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="14"/>
        <source>Amharic</source>
        <translation>Amharische</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="15"/>
        <source>Arabic</source>
        <translation>Arabisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="16"/>
        <source>Armenian</source>
        <translation>Armenisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="17"/>
        <source>Assamese</source>
        <translation>Assamesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="18"/>
        <source>Aymara</source>
        <translation>Aymara</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="19"/>
        <source>Azerbaijani</source>
        <translation>Aserbaidschanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="20"/>
        <source>Bashkir</source>
        <translation>Baschkirisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="21"/>
        <source>Basque</source>
        <translation>Baskisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="22"/>
        <source>Bengali</source>
        <translation>Bengalisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="23"/>
        <source>Bhutani</source>
        <translation>Bhutanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="24"/>
        <source>Bihari</source>
        <translation>Bihari</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="25"/>
        <source>Bislama</source>
        <translation>Bislama</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="26"/>
        <source>Breton</source>
        <translation>Bretonisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="27"/>
        <source>Bulgarian</source>
        <translation>Bulgarisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="28"/>
        <source>Burmese</source>
        <translation>Burmesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="29"/>
        <source>Byelorussian</source>
        <translation>Belarussisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="30"/>
        <source>Cambodian</source>
        <translation>Kambodschanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="31"/>
        <source>Catalan</source>
        <translation>Catalan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="32"/>
        <source>Chinese</source>
        <translation>Chinesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="33"/>
        <source>Corsican</source>
        <translation>Korsisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="34"/>
        <source>Croatian</source>
        <translation>Kroatisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="35"/>
        <source>Czech</source>
        <translation>Tschechisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="36"/>
        <source>Danish</source>
        <translation>Dänisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="37"/>
        <source>Dutch</source>
        <translation>Niederländisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="38"/>
        <source>English</source>
        <translation>Englisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="39"/>
        <source>Esperanto</source>
        <translation>Esperanto</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="40"/>
        <source>Estonian</source>
        <translation>Estnisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="41"/>
        <source>Faroese</source>
        <translation>Färöisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="42"/>
        <source>FijiLanguage</source>
        <translation>Fidschi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="43"/>
        <source>Finnish</source>
        <translation>Finisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="44"/>
        <source>French</source>
        <translation>Französisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="45"/>
        <source>Frisian</source>
        <translation>Friesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="46"/>
        <source>Gaelic</source>
        <translation>Gälisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="47"/>
        <source>Galician</source>
        <translation>Galicisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="48"/>
        <source>Georgian</source>
        <translation>Georgisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="50"/>
        <source>Greek</source>
        <translation>Griechisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="51"/>
        <source>Greenlandic</source>
        <translation>Grönländisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="52"/>
        <source>Guarani</source>
        <translation>Guarani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="53"/>
        <source>Gujarati</source>
        <translation>Gujarati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="54"/>
        <source>Hausa</source>
        <translation>Hausa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="55"/>
        <source>Hebrew</source>
        <translation>Hebräisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="56"/>
        <source>Hindi</source>
        <translation>Hindi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="57"/>
        <source>Hungarian</source>
        <translation>Ungarisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="58"/>
        <source>Icelandic</source>
        <translation>Isländisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="59"/>
        <source>Indonesian</source>
        <translation>Indonesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="60"/>
        <source>Interlingua</source>
        <translation>Interlingua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="61"/>
        <source>Interlingue</source>
        <translation>Interlingue</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="62"/>
        <source>Inuktitut</source>
        <translation>Inuktitut</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="63"/>
        <source>Inupiak</source>
        <translation>Inupiaq</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="64"/>
        <source>Irish</source>
        <translation>Irisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="65"/>
        <source>Italian</source>
        <translation>Italienisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="66"/>
        <source>Japanese</source>
        <translation>Japanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="67"/>
        <source>Javanese</source>
        <translation>Javanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="68"/>
        <source>Kannada</source>
        <translation>Kannada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="69"/>
        <source>Kashmiri</source>
        <translation>Kashmiri</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="70"/>
        <source>Kazakh</source>
        <translation>Kasachisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="71"/>
        <source>Kinyarwanda</source>
        <translation>Kinyarwanda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="72"/>
        <source>Kirghiz</source>
        <translation>Kirgisisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="73"/>
        <source>Korean</source>
        <translation>Koreanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="74"/>
        <source>Kurdish</source>
        <translation>Kurdisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="75"/>
        <source>Kurundi</source>
        <translation>Kurundi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="76"/>
        <source>Laothian</source>
        <translation>Lao</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="77"/>
        <source>Latin</source>
        <translation>Latein</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="78"/>
        <source>Latvian</source>
        <translation>Lettisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="79"/>
        <source>Lingala</source>
        <translation>Lingála</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="80"/>
        <source>Lithuanian</source>
        <translation>Litauisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="81"/>
        <source>Macedonian</source>
        <translation>Mazedonisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="82"/>
        <source>Malagasy</source>
        <translation>Malagasy</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="83"/>
        <source>Malay</source>
        <translation>Malay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="84"/>
        <source>Malayalam</source>
        <translation>Malayalam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="85"/>
        <source>Maltese</source>
        <translation>Maltesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="86"/>
        <source>Maori</source>
        <translation>Māori</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="87"/>
        <source>Marathi</source>
        <translation>Marathi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="88"/>
        <source>Moldavian</source>
        <translation>Moldawisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="89"/>
        <source>Mongolian</source>
        <translation>Momgolisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="90"/>
        <source>NauruLanguage</source>
        <translation>Nauruisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="91"/>
        <source>Nepali</source>
        <translation>Nepali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="92"/>
        <source>Norwegian</source>
        <translation>Norwegisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="93"/>
        <source>NorwegianBokmal</source>
        <translation>Norwegisch (Bokmål)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="94"/>
        <source>Occitan</source>
        <translation>Okzitanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="95"/>
        <source>Oriya</source>
        <translation>Oriya</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="96"/>
        <source>Pashto</source>
        <translation>Paschtu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="97"/>
        <source>Persian</source>
        <translation>Persisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="98"/>
        <source>Polish</source>
        <translation>Polnisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="99"/>
        <source>Portuguese</source>
        <translation>Portugisisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="100"/>
        <source>Punjabi</source>
        <translation>Punjabi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="101"/>
        <source>Quechua</source>
        <translation>Quechua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="102"/>
        <source>RhaetoRomance</source>
        <translation>Rätoromanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="103"/>
        <source>Romanian</source>
        <translation>Rumänisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="104"/>
        <source>Russian</source>
        <translation>Russisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="105"/>
        <source>Samoan</source>
        <translation>Samoisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="106"/>
        <source>Sangho</source>
        <translation>Sangho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="107"/>
        <source>Sanskrit</source>
        <translation>Sanskrit</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="108"/>
        <source>Serbian</source>
        <translation>Serbisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="109"/>
        <source>SerboCroatian</source>
        <translation>Serbo-Kroatisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="110"/>
        <source>Sesotho</source>
        <translation>Sesotho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="111"/>
        <source>Setswana</source>
        <translation>Setswana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="112"/>
        <source>Shona</source>
        <translation>Schona</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="113"/>
        <source>Sindhi</source>
        <translation>Sindhi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="114"/>
        <source>Singhalese</source>
        <translation>Singhalesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="115"/>
        <source>Siswati</source>
        <translation>Siswati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="116"/>
        <source>Slovak</source>
        <translation>Slowakisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="117"/>
        <source>Slovenian</source>
        <translation>Slowenisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="118"/>
        <source>Somali</source>
        <translation>Somali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="119"/>
        <source>Spanish</source>
        <translation>Spanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="120"/>
        <source>Sundanese</source>
        <translation>Sundanesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="121"/>
        <source>Swahili</source>
        <translation>Suaheli</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="122"/>
        <source>Swedish</source>
        <translation>Schwedisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="123"/>
        <source>Tagalog</source>
        <translation>Tagalog</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="124"/>
        <source>Tajik</source>
        <translation>Tadschikisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="125"/>
        <source>Tamil</source>
        <translation>Tamilisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="126"/>
        <source>Tatar</source>
        <translation>Tatarisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="127"/>
        <source>Telugu</source>
        <translation>Telugisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="128"/>
        <source>Thai</source>
        <translation>Thailändisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="129"/>
        <source>Tibetan</source>
        <translation>Tibetanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="130"/>
        <source>Tigrinya</source>
        <translation>Tigrinnisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="131"/>
        <source>TongaLanguage</source>
        <translation>Tongaisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="132"/>
        <source>Tsonga</source>
        <translation>Tsonga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="133"/>
        <source>Turkish</source>
        <translation>Türkisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="134"/>
        <source>Turkmen</source>
        <translation>Turkmenisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="135"/>
        <source>Twi</source>
        <translation>Twi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="136"/>
        <source>Uigur</source>
        <translation>Uigurisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="137"/>
        <source>Ukrainian</source>
        <translation>Ukrainisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="138"/>
        <source>Urdu</source>
        <translation>Urdu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="139"/>
        <source>Uzbek</source>
        <translation>Usbekisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="140"/>
        <source>Vietnamese</source>
        <translation>Vietnamesisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="141"/>
        <source>Volapuk</source>
        <translation>Volapük</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="142"/>
        <source>Welsh</source>
        <translation>Walisisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="143"/>
        <source>Wolof</source>
        <translation>Wolof</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="144"/>
        <source>Xhosa</source>
        <translation>Xhosa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="145"/>
        <source>Yiddish</source>
        <translation>Jiddisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="146"/>
        <source>Yoruba</source>
        <translation>Yoruba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="147"/>
        <source>Zhuang</source>
        <translation>Zhuang</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="148"/>
        <source>Zulu</source>
        <translation>Zulu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="149"/>
        <source>NorwegianNynorsk</source>
        <translation>Norwegisch - Nynorsk</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="150"/>
        <source>Nynorsk</source>
        <translation>Norwegisch - Nynorsk</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="151"/>
        <source>Bosnian</source>
        <translation>Bosnisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="152"/>
        <source>Divehi</source>
        <translation>Divehi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="153"/>
        <source>Manx</source>
        <translation>Manx</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="154"/>
        <source>Cornish</source>
        <translation>Kornisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="155"/>
        <source>Akan</source>
        <translation>Akan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="156"/>
        <source>Konkani</source>
        <translation>Konkani</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="157"/>
        <source>Ga</source>
        <translation>Ga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="158"/>
        <source>Igbo</source>
        <translation>Igbo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="159"/>
        <source>Kamba</source>
        <translation>Kamba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="160"/>
        <source>Syriac</source>
        <translation>Syriakisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="161"/>
        <source>Blin</source>
        <translation>Blin</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="162"/>
        <source>Geez</source>
        <translation>Ge&apos;ez</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="163"/>
        <source>Koro</source>
        <translation>Koro</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="164"/>
        <source>Sidamo</source>
        <translation>Sidama</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="165"/>
        <source>Atsam</source>
        <translation>Atsam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="166"/>
        <source>Tigre</source>
        <translation>Tigre</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="167"/>
        <source>Jju</source>
        <translation>Jju</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="168"/>
        <source>Friulian</source>
        <translation>Furlanisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="169"/>
        <source>Venda</source>
        <translation>Venda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="170"/>
        <source>Ewe</source>
        <translation>Ewe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="171"/>
        <source>Walamo</source>
        <translation>Walamo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="172"/>
        <source>Hawaiian</source>
        <translation>Hawaiisch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="173"/>
        <source>Tyap</source>
        <translation>Tyap</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="177"/>
        <source>Afghanistan</source>
        <translation>Afghanistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="178"/>
        <source>Albania</source>
        <translation>Albanien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="179"/>
        <source>Algeria</source>
        <translation>Algerien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="180"/>
        <source>AmericanSamoa</source>
        <translation>Amerikanisch-Samoa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="181"/>
        <source>Andorra</source>
        <translation>Andorra</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="182"/>
        <source>Angola</source>
        <translation>Angola</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="183"/>
        <source>Anguilla</source>
        <translation>Anguilla</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="184"/>
        <source>Antarctica</source>
        <translation>Antarktis</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="185"/>
        <source>AntiguaAndBarbuda</source>
        <translation>Antigua und Barbuda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="186"/>
        <source>Argentina</source>
        <translation>Argentinien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="187"/>
        <source>Armenia</source>
        <translation>Armenien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="188"/>
        <source>Aruba</source>
        <translation>Aruba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="189"/>
        <source>Australia</source>
        <translation>Australien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="190"/>
        <source>Austria</source>
        <translation>Österreich</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="191"/>
        <source>Azerbaijan</source>
        <translation>Aserbaidschan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="192"/>
        <source>Bahamas</source>
        <translation>Bahamas</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="193"/>
        <source>Bahrain</source>
        <translation>Bahrain</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="194"/>
        <source>Bangladesh</source>
        <translation>Bangladesch</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="195"/>
        <source>Barbados</source>
        <translation>Barbados</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="196"/>
        <source>Belarus</source>
        <translation>Weißrussland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="197"/>
        <source>Belgium</source>
        <translation>Belgien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="198"/>
        <source>Belize</source>
        <translation>Belize</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="199"/>
        <source>Benin</source>
        <translation>Benin</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="200"/>
        <source>Bermuda</source>
        <translation>Bermuda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="201"/>
        <source>Bhutan</source>
        <translation>Bhutan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="202"/>
        <source>Bolivia</source>
        <translation>Bolivien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="203"/>
        <source>BosniaAndHerzegowina</source>
        <translation>Bosnien und Herzegowina</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="204"/>
        <source>Botswana</source>
        <translation>Botswana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="205"/>
        <source>BouvetIsland</source>
        <translation>Bouvetinsel</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="206"/>
        <source>Brazil</source>
        <translation>Brasilien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="207"/>
        <source>BritishIndianOceanTerritory</source>
        <translation>Britisches Territorium im Indischen Ozean</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="208"/>
        <source>BruneiDarussalam</source>
        <translation>Brunei Darussalam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="209"/>
        <source>Bulgaria</source>
        <translation>Bulgarien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="210"/>
        <source>BurkinaFaso</source>
        <translation>Burkina Faso</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="211"/>
        <source>Burundi</source>
        <translation>Burundi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="212"/>
        <source>Cambodia</source>
        <translation>Kambodscha</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="213"/>
        <source>Cameroon</source>
        <translation>Kameroon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="214"/>
        <source>Canada</source>
        <translation>Kanada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="215"/>
        <source>CapeVerde</source>
        <translation>Kap Verde</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="216"/>
        <source>CaymanIslands</source>
        <translation>Kaiman-Inseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="217"/>
        <source>CentralAfricanRepublic</source>
        <translation>Zentralafrikanische Republik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="218"/>
        <source>Chad</source>
        <translation>Tschad</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="219"/>
        <source>Chile</source>
        <translation>Chile</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="220"/>
        <source>China</source>
        <translation>China, Volksrepublik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="221"/>
        <source>ChristmasIsland</source>
        <translation>Weihnachtsinsel</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="222"/>
        <source>CocosIslands</source>
        <translation>Kokosinseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="223"/>
        <source>Colombia</source>
        <translation>Kolumbien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="224"/>
        <source>Comoros</source>
        <translation>Komoren</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="225"/>
        <source>DemocraticRepublicOfCongo</source>
        <translation>Kongo, Demokratische Republik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="226"/>
        <source>PeoplesRepublicOfCongo</source>
        <translation>Kongo, Republik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="227"/>
        <source>CookIslands</source>
        <translation>Cookinseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="228"/>
        <source>CostaRica</source>
        <translation>Costa Rica</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="229"/>
        <source>IvoryCoast</source>
        <translation>Elfenbeinküste</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="230"/>
        <source>Croatia</source>
        <translation>Kroatien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="231"/>
        <source>Cuba</source>
        <translation>Kuba</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="232"/>
        <source>Cyprus</source>
        <translation>Zypern</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="233"/>
        <source>CzechRepublic</source>
        <translation>Tschechische Republik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="234"/>
        <source>Denmark</source>
        <translation>Dänemark</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="235"/>
        <source>Djibouti</source>
        <translation>Dschibuti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="236"/>
        <source>Dominica</source>
        <translation>Domanica</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="237"/>
        <source>DominicanRepublic</source>
        <translation>Dominikanische Republik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="238"/>
        <source>EastTimor</source>
        <translation>Osttimor (Timor-Leste)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="239"/>
        <source>Ecuador</source>
        <translation>Ecuador</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="240"/>
        <source>Egypt</source>
        <translation>Ägypten</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="241"/>
        <source>ElSalvador</source>
        <translation>El Salvador</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="242"/>
        <source>EquatorialGuinea</source>
        <translation>Äquatorialguinea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="243"/>
        <source>Eritrea</source>
        <translation>Eritrea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="244"/>
        <source>Estonia</source>
        <translation>Estland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="245"/>
        <source>Ethiopia</source>
        <translation>Äthiopien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="246"/>
        <source>FalklandIslands</source>
        <translation>Falklandinseln (Malwinen)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="247"/>
        <source>FaroeIslands</source>
        <translation>Färöer-Inseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="248"/>
        <source>FijiCountry</source>
        <translation>Fidschi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="249"/>
        <source>Finland</source>
        <translation>Finnland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="250"/>
        <source>France</source>
        <translation>Frankreich</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="251"/>
        <source>MetropolitanFrance</source>
        <translation>Metropolitan-Frankreich</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="252"/>
        <source>FrenchGuiana</source>
        <translation>Französisch-Guayana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="253"/>
        <source>FrenchPolynesia</source>
        <translation>Französisch-Polynesien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="254"/>
        <source>FrenchSouthernTerritories</source>
        <translation>Französische Süd- und Antarktisgebiete</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="255"/>
        <source>Gabon</source>
        <translation>Gabun</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="256"/>
        <source>Gambia</source>
        <translation>Gambia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="257"/>
        <source>Georgia</source>
        <translation>Georgien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="258"/>
        <source>Germany</source>
        <translation>Deutschland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="259"/>
        <source>Ghana</source>
        <translation>Ghana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="260"/>
        <source>Gibraltar</source>
        <translation>Gibraltar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="261"/>
        <source>Greece</source>
        <translation>Griechenland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="262"/>
        <source>Greenland</source>
        <translation>Grönland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="263"/>
        <source>Grenada</source>
        <translation>Grenada</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="264"/>
        <source>Guadeloupe</source>
        <translation>Guadeloupe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="265"/>
        <source>Guam</source>
        <translation>Guam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="266"/>
        <source>Guatemala</source>
        <translation>Guatemala</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="267"/>
        <source>Guinea</source>
        <translation>Guinea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="268"/>
        <source>GuineaBissau</source>
        <translation>Guinea-Bissau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="269"/>
        <source>Guyana</source>
        <translation>Guyana</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="270"/>
        <source>Haiti</source>
        <translation>Haiti</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="271"/>
        <source>HeardAndMcDonaldIslands</source>
        <translation>Heard und McDonaldinseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="272"/>
        <source>Honduras</source>
        <translation>Honduras</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="273"/>
        <source>HongKong</source>
        <translation>Hong Kong</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="274"/>
        <source>Hungary</source>
        <translation>Ungarn</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="275"/>
        <source>Iceland</source>
        <translation>Island</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="276"/>
        <source>India</source>
        <translation>Indien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="277"/>
        <source>Indonesia</source>
        <translation>Indonesien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="278"/>
        <source>Iran</source>
        <translation>Iran</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="279"/>
        <source>Iraq</source>
        <translation>Irak</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="280"/>
        <source>Ireland</source>
        <translation>Irland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="281"/>
        <source>Israel</source>
        <translation>Israel</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="282"/>
        <source>Italy</source>
        <translation>Italien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="283"/>
        <source>Jamaica</source>
        <translation>Jamaika</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="284"/>
        <source>Japan</source>
        <translation>Japan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="285"/>
        <source>Jordan</source>
        <translation>Jordanien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="286"/>
        <source>Kazakhstan</source>
        <translation>Kasachistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="287"/>
        <source>Kenya</source>
        <translation>Kenia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="288"/>
        <source>Kiribati</source>
        <translation>Kiribati</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="289"/>
        <source>DemocraticRepublicOfKorea</source>
        <translation>Nordkorea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="290"/>
        <source>RepublicOfKorea</source>
        <translation>Südkorea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="291"/>
        <source>Kuwait</source>
        <translation>Kuwait</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="292"/>
        <source>Kyrgyzstan</source>
        <translation>Kirgisistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="293"/>
        <source>Lao</source>
        <translation>Laos</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="294"/>
        <source>Latvia</source>
        <translation>Lettland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="295"/>
        <source>Lebanon</source>
        <translation>Libanon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="296"/>
        <source>Lesotho</source>
        <translation>Lesotho</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="297"/>
        <source>Liberia</source>
        <translation>Liberia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="298"/>
        <source>LibyanArabJamahiriya</source>
        <translation>Libyen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="299"/>
        <source>Liechtenstein</source>
        <translation>Liechtenstein</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="300"/>
        <source>Lithuania</source>
        <translation>Litauen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="301"/>
        <source>Luxembourg</source>
        <translation>Luxemburg</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="302"/>
        <source>Macau</source>
        <translation>Macao</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="303"/>
        <source>Macedonia</source>
        <translation>Mazedonien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="304"/>
        <source>Madagascar</source>
        <translation>Madagaskar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="305"/>
        <source>Malawi</source>
        <translation>Malawi</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="306"/>
        <source>Malaysia</source>
        <translation>Malaysia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="307"/>
        <source>Maldives</source>
        <translation>Malediven</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="308"/>
        <source>Mali</source>
        <translation>Mali</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="309"/>
        <source>Malta</source>
        <translation>Malta</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="310"/>
        <source>MarshallIslands</source>
        <translation>Marshallinseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="311"/>
        <source>Martinique</source>
        <translation>Martinique</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="312"/>
        <source>Mauritania</source>
        <translation>Mauretanien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="313"/>
        <source>Mauritius</source>
        <translation>Mauritius</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="314"/>
        <source>Mayotte</source>
        <translation>Mayotte</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="315"/>
        <source>Mexico</source>
        <translation>Mexiko</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="316"/>
        <source>Micronesia</source>
        <translation>Micronesien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="317"/>
        <source>Moldova</source>
        <translation>Moldau (Moldawien)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="318"/>
        <source>Monaco</source>
        <translation>Monaco</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="319"/>
        <source>Mongolia</source>
        <translation>Mongolei</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="320"/>
        <source>Montserrat</source>
        <translation>Montserrat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="321"/>
        <source>Morocco</source>
        <translation>Marokko</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="322"/>
        <source>Mozambique</source>
        <translation>Mosambik</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="323"/>
        <source>Myanmar</source>
        <translation>Myanmar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="324"/>
        <source>Namibia</source>
        <translation>Namibia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="325"/>
        <source>NauruCountry</source>
        <translation>Nauru</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="326"/>
        <source>Nepal</source>
        <translation>Nepal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="327"/>
        <source>Netherlands</source>
        <translation>Niederlande</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="328"/>
        <source>NetherlandsAntilles</source>
        <translation>Niederländische Antillen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="329"/>
        <source>NewCaledonia</source>
        <translation>Neukaledonien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="330"/>
        <source>NewZealand</source>
        <translation>Neuseeland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="331"/>
        <source>Nicaragua</source>
        <translation>Nicaragua</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="332"/>
        <source>Niger</source>
        <translation>Niger</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="333"/>
        <source>Nigeria</source>
        <translation>Nigeria</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="334"/>
        <source>Niue</source>
        <translation>Niue</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="335"/>
        <source>NorfolkIsland</source>
        <translation>Norfolkinsel</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="336"/>
        <source>NorthernMarianaIslands</source>
        <translation>Nördliche Marianen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="337"/>
        <source>Norway</source>
        <translation>Norwegen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="338"/>
        <source>Oman</source>
        <translation>Oman</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="339"/>
        <source>Pakistan</source>
        <translation>Pakistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="340"/>
        <source>Palau</source>
        <translation>Palau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="341"/>
        <source>PalestinianTerritory</source>
        <translation>Palästinensische Autonomiegebiete</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="342"/>
        <source>Panama</source>
        <translation>Panama</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="343"/>
        <source>PapuaNewGuinea</source>
        <translation>Papua-Neuguinea</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="344"/>
        <source>Paraguay</source>
        <translation>Paraguay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="345"/>
        <source>Peru</source>
        <translation>Peru</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="346"/>
        <source>Philippines</source>
        <translation>Philippinen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="347"/>
        <source>Pitcairn</source>
        <translation>Pitcairninseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="348"/>
        <source>Poland</source>
        <translation>Polen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="349"/>
        <source>Portugal</source>
        <translation>Portugal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="350"/>
        <source>PuertoRico</source>
        <translation>Puerto Rico</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="351"/>
        <source>Qatar</source>
        <translation>Katar</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="352"/>
        <source>Reunion</source>
        <translation>Réunion</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="353"/>
        <source>Romania</source>
        <translation>Rumänien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="354"/>
        <source>RussianFederation</source>
        <translation>Russische Föderation (Russland)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="355"/>
        <source>Rwanda</source>
        <translation>Ruanda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="356"/>
        <source>SaintKittsAndNevis</source>
        <translation>St. Kitts und Nevis</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="357"/>
        <source>StLucia</source>
        <translation>St. Lucia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="358"/>
        <source>StVincentAndTheGrenadines</source>
        <translation>St. Vincent und die Grenadinen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="359"/>
        <source>Samoa</source>
        <translation>Samoa</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="360"/>
        <source>SanMarino</source>
        <translation>San Marino</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="361"/>
        <source>SaoTomeAndPrincipe</source>
        <translation>São Tomé und Príncipe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="362"/>
        <source>SaudiArabia</source>
        <translation>Saudi-Arabien </translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="363"/>
        <source>Senegal</source>
        <translation>Senegal</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="364"/>
        <source>Seychelles</source>
        <translation>Seychellen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="365"/>
        <source>SierraLeone</source>
        <translation>Sierra Leone</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="366"/>
        <source>Singapore</source>
        <translation>Singapur</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="367"/>
        <source>Slovakia</source>
        <translation>Slowakei (Slowakische Republik )</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="368"/>
        <source>Slovenia</source>
        <translation>Slowenien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="369"/>
        <source>SolomonIslands</source>
        <translation>Salomonen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="370"/>
        <source>Somalia</source>
        <translation>Somalia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="371"/>
        <source>SouthAfrica</source>
        <translation>Südafrika</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="372"/>
        <source>SouthGeorgiaAndTheSouthSandwichIslands</source>
        <translation>Südgeorgien und die Südlichen Sandwichinseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="373"/>
        <source>Spain</source>
        <translation>Spanien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="374"/>
        <source>SriLanka</source>
        <translation>Sri Lanka</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="375"/>
        <source>StHelena</source>
        <translation>St. Helena</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="376"/>
        <source>StPierreAndMiquelon</source>
        <translation>Saint-Pierre und Miquelon</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="377"/>
        <source>Sudan</source>
        <translation>Sudan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="378"/>
        <source>Suriname</source>
        <translation>Suriname</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="379"/>
        <source>SvalbardAndJanMayenIslands</source>
        <translation>Svalbard &amp; Jan Mayen Inseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="380"/>
        <source>Swaziland</source>
        <translation>Swasiland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="381"/>
        <source>Sweden</source>
        <translation>Schweden</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="382"/>
        <source>Switzerland</source>
        <translation>Schweiz, Schweizerische Eidgenossenschaft</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="383"/>
        <source>SyrianArabRepublic</source>
        <translation>Syrien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="384"/>
        <source>Taiwan</source>
        <translation>Taiwan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="385"/>
        <source>Tajikistan</source>
        <translation>Tadschikistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="386"/>
        <source>Tanzania</source>
        <translation>Tansania</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="387"/>
        <source>Thailand</source>
        <translation>Thailand</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="388"/>
        <source>Togo</source>
        <translation>Togo</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="389"/>
        <source>Tokelau</source>
        <translation>Tokelau</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="390"/>
        <source>TongaCountry</source>
        <translation>Tonga</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="391"/>
        <source>TrinidadAndTobago</source>
        <translation>Trinidad und Tobago</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="392"/>
        <source>Tunisia</source>
        <translation>Tunesien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="393"/>
        <source>Turkey</source>
        <translation>Türkei</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="394"/>
        <source>Turkmenistan</source>
        <translation>Turkmenistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="395"/>
        <source>TurksAndCaicosIslands</source>
        <translation>Turks- und Caicosinseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="396"/>
        <source>Tuvalu</source>
        <translation>Tuvalu</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="397"/>
        <source>Uganda</source>
        <translation>Uganda</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="398"/>
        <source>Ukraine</source>
        <translation>Ukraine</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="399"/>
        <source>UnitedArabEmirates</source>
        <translation>Vereinigte Arabische Emirate</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="400"/>
        <source>UnitedKingdom</source>
        <translation>Vereintes Königreich Großbritannien und Nordirland</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="401"/>
        <source>UnitedStates</source>
        <translation>Vereinigte Staaten von Amerika</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="402"/>
        <source>UnitedStatesMinorOutlyingIslands</source>
        <translation>United States Minor Outlying Islands</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="403"/>
        <source>Uruguay</source>
        <translation>Uruguay</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="404"/>
        <source>Uzbekistan</source>
        <translation>Usbekistan</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="405"/>
        <source>Vanuatu</source>
        <translation>Vanuat</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="406"/>
        <source>VaticanCityState</source>
        <translation>Heiliger Stuhl (Staat Vatikanstadt)</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="407"/>
        <source>Venezuela</source>
        <translation>Venezuela</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="408"/>
        <source>VietNam</source>
        <translation>Vietnam</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="409"/>
        <source>BritishVirginIslands</source>
        <translation>Britische Jungferninseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="410"/>
        <source>USVirginIslands</source>
        <translation>Amerikanische Jungferninseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="411"/>
        <source>WallisAndFutunaIslands</source>
        <translation>Wallis und Futuna Inseln</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="412"/>
        <source>WesternSahara</source>
        <translation>Westsahara</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="413"/>
        <source>Yemen</source>
        <translation>Jemen</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="414"/>
        <source>Yugoslavia</source>
        <translation>Jugoslawien</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="415"/>
        <source>Zambia</source>
        <translation>Sambia</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="416"/>
        <source>Zimbabwe</source>
        <translation>Simbabwe</translation>
    </message>
    <message>
        <location filename="gen_qlocale.cpp" line="176"/>
        <source>AnyCountry</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QxtCommandOptions</name>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="32"/>
        <source>sets the application GUI style</source>
        <translation>Setzt den GUI Style der Applikation</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="33"/>
        <source>sets the application stylesheet</source>
        <translation>Setzt das Stylesheet der Applikation</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="34"/>
        <source>restores the application from an earlier session</source>
        <translation>Stellt die Applikation aus einer früheren Session wieder her</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="35"/>
        <source>displays debugging information about widgets</source>
        <translation>Zeigt Debug Informationen der Widgets an</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="36"/>
        <source>use right-to-left layout</source>
        <translation>Nutze Rechts-Nach-Links Layout</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="38"/>
        <source>never grab the mouse or keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="41"/>
        <source>grab the mouse/keyboard even in a debugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="42"/>
        <source>run in synchronous mode for debugging</source>
        <translation>Synchroner Modus aktive für Debug Zwecke</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="45"/>
        <source>use Direct3D by default</source>
        <translation>Benutze Direct3D <byte value="x9"/>standardmäßig</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="48"/>
        <source>sets the X11 display</source>
        <translation>Setzt das X11 Display</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="49"/>
        <source>sets the geometry of the first window</source>
        <translation>Setzt die Geometrie des ersten Fensters</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="51"/>
        <source>sets the default font</source>
        <translation>Setzt den Standardzeichensatz</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="53"/>
        <source>sets the default background color</source>
        <translation>Setzt die Standardhintergrundfarbe</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="55"/>
        <source>sets the default foreground color</source>
        <translation>Setzt die Standardvordergrundfarbe</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="57"/>
        <source>sets the default button color</source>
        <translation>Setzt die Standardfarbe für Buttons</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="58"/>
        <source>sets the application name</source>
        <translation>Setzt den Namen der Applikation</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="59"/>
        <source>sets the application title</source>
        <translation>Setzt den Titel der Applikation</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="60"/>
        <source>sets the X11 visual type</source>
        <translation>Setzt den X11 &apos;Visual Type&apos;</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="61"/>
        <source>limit the number of colors on an 8-bit display</source>
        <translation>Begrenzt die Anzahl der Farben auf einem 8-Bit Bildschirm</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="62"/>
        <source>use a private color map</source>
        <translation>Verwende eine private Farbetabelle</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="63"/>
        <source>sets the input method server</source>
        <translation>Setzt den Eingabemethoden-Server</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="64"/>
        <source>disable the X Input Method</source>
        <translation>Abschalten der &apos;X Input Method&apos;</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="65"/>
        <source>sets the style used by the input method</source>
        <translation>Setzt den Style der Eingabemethode</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="289"/>
        <source>Short options cannot have optional parameters</source>
        <translation>Kurze Optionen haben keine optionalen Parameter</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="300"/>
        <source>positional() called before parse()</source>
        <translation>positional() wurde vor parse() aufgerufen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="356"/>
        <source>unrecognized() called before parse()</source>
        <translation>unrecognized() wurde vor parse() aufgerufen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="325"/>
        <source>count() called before parse()</source>
        <translation>count() wurde vor parse() aufgerufen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="342"/>
        <source>value() called before parse()</source>
        <translation>value() wurde vor parse() aufgerufen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="581"/>
        <source>unrecognized parameters: </source>
        <translation>Nicht erkannte Parameter:</translation>
    </message>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="584"/>
        <source>%1 requires a parameter</source>
        <translation>%1 benötigt einen Parameter</translation>
    </message>
</context>
<context>
    <name>QxtCommandOptionsPrivate</name>
    <message>
        <location filename="../src/core/qxtcommandoptions.cpp" line="164"/>
        <source>option &quot;%1&quot; not found</source>
        <translation>Option &quot;%1&quot; nicht gefunden</translation>
    </message>
</context>
<context>
    <name>QxtConfigDialog</name>
    <message>
        <location filename="../src/gui/qxtconfigdialog.cpp" line="132"/>
        <source>&amp;OK</source>
        <translation>&amp;Ok</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtconfigdialog.cpp" line="133"/>
        <source>&amp;Cancel</source>
        <translation>&amp;Abbrechen</translation>
    </message>
</context>
<context>
    <name>QxtConfirmationMessage</name>
    <message>
        <location filename="../src/gui/qxtconfirmationmessage.cpp" line="74"/>
        <source>Do not show again.</source>
        <translation>Nicht noch einmal anzeigen.</translation>
    </message>
</context>
<context>
    <name>QxtCountryComboBox</name>
    <message>
        <location filename="../src/gui/qxtcountrycombobox.cpp" line="109"/>
        <source>DESIGNER MODE  -  DESIGNER MODE</source>
        <translation></translation>
    </message>
</context>
<context>
    <name>QxtCountryModel</name>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="205"/>
        <source>Name</source>
        <translation>Name</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="207"/>
        <source>ISO 3166 Alpha 2</source>
        <translation>ISO 3166 Alpha 2</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="209"/>
        <source>QLocale</source>
        <translation>QLocale</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="211"/>
        <source>ISO 3166 Alpha 3</source>
        <translation>ISO 3166 Alpha 3</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="213"/>
        <source>Currency</source>
        <translation>Währung</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="215"/>
        <source>Currency Code</source>
        <translation>Währungscode</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="217"/>
        <source>Currency Symbol</source>
        <translation>Währungssymbol</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtcountrymodel.cpp" line="219"/>
        <source>Continent</source>
        <translation>Kontinent</translation>
    </message>
</context>
<context>
    <name>QxtLocale</name>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="766"/>
        <source>*No Currency*</source>
        <translation>*Keine Währung*</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="767"/>
        <source>Afghani</source>
        <translation>Afghani</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="768"/>
        <source>Algerian Dinar</source>
        <translation>Algerischer Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="769"/>
        <source>Argentine Peso</source>
        <translation>Argentinischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="770"/>
        <source>Armenian Dram</source>
        <translation>Dram</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="771"/>
        <source>Aruban Guilder</source>
        <translation>Aruba-Gulden</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="772"/>
        <source>Australian Dollar</source>
        <translation>Australischer Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="773"/>
        <source>Azerbaijanian Manat</source>
        <translation>Aserbaidschan-Manat</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="774"/>
        <source>Bahamian Dollar</source>
        <translation>Bahama-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="775"/>
        <source>Bahraini Dinar</source>
        <translation>Bahrain-Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="776"/>
        <source>Baht</source>
        <translation>Baht</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="777"/>
        <source>Balboa</source>
        <translation>Balboa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="778"/>
        <source>Barbados Dollar</source>
        <translation>Barbados-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="779"/>
        <source>Belarussian Ruble</source>
        <translation>Weißrussischer Rubel</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="780"/>
        <source>Belize Dollar</source>
        <translation>Belize-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="781"/>
        <source>Bermudian Dollar</source>
        <translation>Bermuda-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="782"/>
        <source>Bolivar Fuerte</source>
        <translation>Bolívar Fuerte</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="783"/>
        <source>Boliviano</source>
        <translation>Boliviano</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="784"/>
        <source>Brazilian Real</source>
        <translation>Brasilianischer Real</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="785"/>
        <source>Brunei Dollar</source>
        <translation>Brunei-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="786"/>
        <source>Bulgarian Lev</source>
        <translation>Lew</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="787"/>
        <source>Burundi Franc</source>
        <translation>Burundi-Franc</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="788"/>
        <source>CFA Franc BCEAO</source>
        <translation>CFA-Franc BCEAO</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="789"/>
        <source>CFA Franc BEAC</source>
        <translation>CFA-Franc BEAC</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="790"/>
        <source>CFP Franc</source>
        <translation>CFP-Franc</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="791"/>
        <source>Canadian Dollar</source>
        <translation>Kanadischer Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="792"/>
        <source>Cape Verde Escudo</source>
        <translation>Kap-Verde-Escudo</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="793"/>
        <source>Cayman Islands Dollar</source>
        <translation>Kaiman-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="794"/>
        <source>Chilean Peso</source>
        <translation>Chilenischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="795"/>
        <source>Colombian Peso</source>
        <translation>Kolumbianischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="796"/>
        <source>Comoro Franc</source>
        <translation>Komoren-Franc</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="797"/>
        <source>Convertible Marks</source>
        <translation>Konvertible Mark</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="798"/>
        <source>Cordoba Oro</source>
        <translation>Córdoba Oro</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="799"/>
        <source>Costa Rican Colon</source>
        <translation>Costa-Rica-Colón</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="800"/>
        <source>Croatian Kuna</source>
        <translation>Kroatische Kuna</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="801"/>
        <source>Cuban Peso</source>
        <translation>Kubanischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="802"/>
        <source>Cyprus Pound</source>
        <translation>Zypern-Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="803"/>
        <source>Czech Koruna</source>
        <translation>Tscheckische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="804"/>
        <source>Dalasi</source>
        <translation>Dalasi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="805"/>
        <source>Danish Krone</source>
        <translation>Dänische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="806"/>
        <source>Denar</source>
        <translation>Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="807"/>
        <source>Djibouti Franc</source>
        <translation>Dschibuti-Franc</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="808"/>
        <source>Dobra</source>
        <translation>Dobra</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="809"/>
        <source>Dominican Peso</source>
        <translation>Dominikanischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="810"/>
        <source>Dong</source>
        <translation>Đồng</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="811"/>
        <source>East Caribbean Dollar</source>
        <translation>Ostkaribischer Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="812"/>
        <source>Egyptian Pound</source>
        <translation>Ägyptisches Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="813"/>
        <source>El Salvador Colon</source>
        <translation>El-Salvador-Colón</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="814"/>
        <source>Ethiopian Birr</source>
        <translation>Birr</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="815"/>
        <source>Euro</source>
        <translation>Euro</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="816"/>
        <source>Falkland Islands Pound</source>
        <translation>Falkland-Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="817"/>
        <source>Fiji Dollar</source>
        <translation>Fidschi-Dolar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="818"/>
        <source>Forint</source>
        <translation>Porint</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="819"/>
        <source>Franc Congolais</source>
        <translation>Kongo-Franc</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="820"/>
        <source>Ghana Cedi</source>
        <translation>Cedi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="821"/>
        <source>Gibraltar Pound</source>
        <translation>Gibraltar-Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="822"/>
        <source>Gourde</source>
        <translation>Gourde</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="823"/>
        <source>Guarani</source>
        <translation>Guarani</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="824"/>
        <source>Guinea-Bissau Peso</source>
        <translation>Guinea-Bissau-Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="825"/>
        <source>Guinea Franc</source>
        <translation>Franc Guinéen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="826"/>
        <source>Guyana Dollar</source>
        <translation>Guyana-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="827"/>
        <source>Hong Kong Dollar</source>
        <translation>Hongkong-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="828"/>
        <source>Hryvnia</source>
        <translation>Hrywnja</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="829"/>
        <source>Iceland Krona</source>
        <translation>Isländische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="830"/>
        <source>Indian Rupee</source>
        <translation>Indische Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="831"/>
        <source>Iranian Rial</source>
        <translation>Iranischer Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="832"/>
        <source>Iraqi Dinar</source>
        <translation>Irakischer Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="833"/>
        <source>Jamaican Dollar</source>
        <translation>Jamaika-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="834"/>
        <source>Jordanian Dinar</source>
        <translation>Jordanischer-Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="835"/>
        <source>Kenyan Shilling</source>
        <translation>Kenia-Schilling</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="836"/>
        <source>Kina</source>
        <translation>Kina</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="837"/>
        <source>Kip</source>
        <translation>Kip</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="838"/>
        <source>Kroon</source>
        <translation>Estnische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="839"/>
        <source>Kuwaiti Dinar</source>
        <translation>Kuwait-Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="840"/>
        <source>Kwanza</source>
        <translation>Kwanza</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="841"/>
        <source>Kyat</source>
        <translation>Kyat</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="842"/>
        <source>Lari</source>
        <translation>Georgischer Lari</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="843"/>
        <source>Latvian Lats</source>
        <translation>Lats</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="844"/>
        <source>Lebanese Pound</source>
        <translation>Libanesisches Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="845"/>
        <source>Lek</source>
        <translation>Lek</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="846"/>
        <source>Lempira</source>
        <translation>Lempira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="847"/>
        <source>Leone</source>
        <translation>Leone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="848"/>
        <source>Liberian Dollar</source>
        <translation>Liberianischer Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="849"/>
        <source>Libyan Dinar</source>
        <translation>Libyyscher Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="850"/>
        <source>Lilangeni</source>
        <translation>Lilangeni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="851"/>
        <source>Lithuanian Litas</source>
        <translation>Litas</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="852"/>
        <source>Loti</source>
        <translation>Loti</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="853"/>
        <source>Malagasy Ariary</source>
        <translation>Ariary</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="855"/>
        <source>Malaysian Ringgit</source>
        <translation>Ringit</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="856"/>
        <source>Maltese Lira</source>
        <translation>Maltesische Lira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="857"/>
        <source>Manat</source>
        <translation>Manat</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="858"/>
        <source>Mauritius Rupee</source>
        <translation>Mauritius-Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="859"/>
        <source>Metical</source>
        <translation>Metical</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="860"/>
        <source>Mexican Peso</source>
        <translation>Mexikanischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="861"/>
        <source>Mexican Unidad de Inversion</source>
        <translation>Mexican Unidad de Inversion</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="862"/>
        <source>Moldovan Leu</source>
        <translation>Moldauischer Leu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="863"/>
        <source>Moroccan Dirham</source>
        <translation>Marokkanischer Dirham</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="864"/>
        <source>Mvdol</source>
        <translation>Mvdol</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="865"/>
        <source>Naira</source>
        <translation>Naira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="866"/>
        <source>Nakfa</source>
        <translation>Nakfa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="867"/>
        <source>Namibia Dollar</source>
        <translation>Namibia-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="868"/>
        <source>Nepalese Rupee</source>
        <translation>Nepalesische Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="869"/>
        <source>Netherlands Antillian Guilder</source>
        <translation>Niederländische-Antillen-Gulden</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="870"/>
        <source>New Israeli Sheqel</source>
        <translation>Schekel</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="871"/>
        <source>New Leu</source>
        <translation>Rumänischer Leu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="872"/>
        <source>New Taiwan Dollar</source>
        <translation>Neuer Taiwan-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="873"/>
        <source>New Turkish Lira</source>
        <translation>Türkische Lira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="874"/>
        <source>New Zealand Dollar</source>
        <translation>Neuseeland-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="875"/>
        <source>Ngultrum</source>
        <translation>Ngultrum</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="876"/>
        <source>North Korean Won</source>
        <translation>Won (Nordkorea)</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="877"/>
        <source>Norwegian Krone</source>
        <translation>Norwegische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="878"/>
        <source>Nuevo Sol</source>
        <translation>Nuevo Sol</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="879"/>
        <source>Ouguiya</source>
        <translation>Ouguiya</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="880"/>
        <source>Pa&apos;anga</source>
        <translation>Pa&apos;anga</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="881"/>
        <source>Pakistan Rupee</source>
        <translation>Pakistanische Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="882"/>
        <source>Pataca</source>
        <translation>Pataca</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="883"/>
        <source>Peso Uruguayo</source>
        <translation>Uruguayischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="884"/>
        <source>Philippine Peso</source>
        <translation>Philippinischer Peso</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="885"/>
        <source>Pound Sterling</source>
        <translation>Pfund Sterling</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="886"/>
        <source>Pula</source>
        <translation>Pula</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="887"/>
        <source>Qatari Rial</source>
        <translation>Katar-Riyal</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="888"/>
        <source>Quetzal</source>
        <translation>Quetzal</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="889"/>
        <source>Rand</source>
        <translation>Rand</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="890"/>
        <source>Rial Omani</source>
        <translation>Omani Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="891"/>
        <source>Riel</source>
        <translation>Riel</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="892"/>
        <source>Rufiyaa</source>
        <translation>Rufiyaa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="893"/>
        <source>Rupiah</source>
        <translation>Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="894"/>
        <source>Russian Ruble</source>
        <translation>Russische Rubel</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="895"/>
        <source>Rwanda Franc</source>
        <translation>Ruanda-Franc</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="896"/>
        <source>Saint Helena Pound</source>
        <translation>St.Helena-Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="897"/>
        <source>Saudi Riyal</source>
        <translation>Saudi-Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="898"/>
        <source>Serbian Dinar</source>
        <translation>Serbischer Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="899"/>
        <source>Seychelles Rupee</source>
        <translation>Seychellen-Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="900"/>
        <source>Singapore Dollar</source>
        <translation>Singapur-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="901"/>
        <source>Slovak Koruna</source>
        <translation>Slowakische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="902"/>
        <source>Solomon Islands Dollar</source>
        <translation>Salmonen-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="903"/>
        <source>Som</source>
        <translation>Soʻm</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="904"/>
        <source>Somali Shilling</source>
        <translation>Somalia-Schilling</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="905"/>
        <source>Somoni</source>
        <translation>Somoni</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="906"/>
        <source>Sri Lanka Rupee</source>
        <translation>Sri-Lanka-Rupie</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="907"/>
        <source>Sudanese Pound</source>
        <translation>Sudanesisches Pfund</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="908"/>
        <source>Surinam Dollar</source>
        <translation>Suriname-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="909"/>
        <source>Swedish Krona</source>
        <translation>Schwedische Krone</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="910"/>
        <source>Swiss Franc</source>
        <translation>Schweizer Franken</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="911"/>
        <source>Syrian Pound</source>
        <translation>Syrische Lira</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="912"/>
        <source>Taka</source>
        <translation>Taka</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="913"/>
        <source>Tala</source>
        <translation>Tala</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="914"/>
        <source>Tanzanian Shilling</source>
        <translation>Tansania-Schilling</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="915"/>
        <source>Tenge</source>
        <translation>Tenge</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="916"/>
        <source>Trinidad and Tobago Dollar</source>
        <translation>Trinidad-und-Tobago-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="917"/>
        <source>Tugrik</source>
        <translation>Mongolischer Tögrög</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="918"/>
        <source>Tunisian Dinar</source>
        <translation>Tunesischer Dinar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="919"/>
        <source>UAE Dirham</source>
        <translation>VAE-Dirham</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="920"/>
        <source>US Dollar</source>
        <translation>US-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="921"/>
        <source>Uganda Shilling</source>
        <translation>Uganda-Schilling</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="922"/>
        <source>Unidad de Valor Real</source>
        <translation>Unidad de Valor Real</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="923"/>
        <source>Unidades de fomento</source>
        <translation>Unidades de fomento</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="924"/>
        <source>Uruguay Peso en Unidades Indexadas</source>
        <translation>Uruguay Peso en Unidades Indexadas</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="925"/>
        <source>Uzbekistan Sum</source>
        <translation>Soʻm</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="926"/>
        <source>Vatu</source>
        <translation>Vatu</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="927"/>
        <source>Won</source>
        <translation>Won (Südkorea)</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="928"/>
        <source>Yemeni Rial</source>
        <translation>Jemen-Rial</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="929"/>
        <source>Yen</source>
        <translation>Yen</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="930"/>
        <source>Yuan Renminbi</source>
        <translation>Renminbi</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="932"/>
        <source>Zimbabwe Dollar</source>
        <translation>Simbabwe-Dollar</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="933"/>
        <source>Zloty</source>
        <translation>Zloty</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1279"/>
        <source>NorthAmerica</source>
        <translation>Nordamerika</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1280"/>
        <source>SouthAmerica</source>
        <translation>Südamerika</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1281"/>
        <source>Europe</source>
        <translation>Europa</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1282"/>
        <source>Africa</source>
        <translation>Afrika</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1283"/>
        <source>Asia</source>
        <translation>Asien</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1284"/>
        <source>Australia</source>
        <translation>Australien</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1285"/>
        <source>Antarctica</source>
        <translation>Antarktis</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="854"/>
        <source>MalawiKwacha</source>
        <translation>Malawi-Kwacha</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="931"/>
        <source>ZambiaKwacha</source>
        <translation>Sambischer Kwacha</translation>
    </message>
    <message>
        <location filename="../src/core/qxtlocale_data_p.h" line="1278"/>
        <source>None</source>
        <translation>Kein Kontinent</translation>
    </message>
</context>
<context>
    <name>QxtProgressLabel</name>
    <message>
        <location filename="../src/gui/qxtprogresslabel.cpp" line="236"/>
        <source>mm:ss</source>
        <translation>mm:ss</translation>
    </message>
    <message>
        <location filename="../src/gui/qxtprogresslabel.cpp" line="239"/>
        <source>ETA: %r</source>
        <translation>GAZ: %r</translation>
    </message>
</context>
</TS>
