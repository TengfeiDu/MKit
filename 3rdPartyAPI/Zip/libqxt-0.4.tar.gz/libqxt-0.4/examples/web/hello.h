#include <QxtWebController>


class HelloWorld : public QxtWebController
{
Q_OBJECT
public:
    HelloWorld();
public slots:
    int index();
};


